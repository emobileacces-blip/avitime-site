<?php
/**
 * Avitime tester orders: shipping events sent to Avitime, retries, order screen.
 *
 * An order created by an Avitime link carries the meta « _avitime_authorization_ref ».
 *
 * @package Avitime
 */

defined( 'ABSPATH' ) || exit;

class Avitime_WC_Orders {

	const META_REF      = '_avitime_authorization_ref';
	const META_MISSION  = '_avitime_mission_ref';
	const META_TESTER   = '_avitime_tester_ref';
	const META_EVENT    = '_avitime_last_event';
	const META_PENDING  = '_avitime_sync_pending';
	const META_CARRIER  = '_avitime_carrier';
	const META_TRACKING = '_avitime_tracking_number';
	const META_URL      = '_avitime_tracking_url';

	public static function is_avitime( $order ) {
		return $order instanceof WC_Order && '' !== (string) $order->get_meta( self::META_REF );
	}

	/** Data sent to Avitime when the order is created (or re-sent). */
	public static function order_payload( WC_Order $order ) {
		$products = array();
		foreach ( $order->get_items() as $item ) {
			if ( ! $item instanceof WC_Order_Item_Product ) {
				continue;
			}
			$products[] = array(
				'id'             => (int) $item->get_product_id(),
				'combination_id' => (int) $item->get_variation_id(),
				'quantity'       => (int) $item->get_quantity(),
			);
		}
		$created = $order->get_date_created();
		return array(
			'authorization_ref' => (string) $order->get_meta( self::META_REF ),
			'order_id'          => (int) $order->get_id(),
			'order_reference'   => (string) $order->get_order_number(),
			'created_at'        => $created ? gmdate( 'c', $created->getTimestamp() ) : gmdate( 'c' ),
			'products'          => $products,
		);
	}

	/**
	 * Tracking known for the order: Avitime box first, then « Shipment Tracking » style plugins.
	 *
	 * @return array{0:string,1:string,2:string} number, carrier, URL
	 */
	public static function tracking( WC_Order $order ) {
		$number  = (string) $order->get_meta( self::META_TRACKING );
		$carrier = (string) $order->get_meta( self::META_CARRIER );
		$url     = (string) $order->get_meta( self::META_URL );
		if ( '' === $number ) {
			$items = $order->get_meta( '_wc_shipment_tracking_items' );
			if ( is_array( $items ) && $items ) {
				$last    = end( $items );
				$number  = isset( $last['tracking_number'] ) ? (string) $last['tracking_number'] : '';
				$carrier = ! empty( $last['custom_tracking_provider'] ) ? (string) $last['custom_tracking_provider'] : ( isset( $last['tracking_provider'] ) ? (string) $last['tracking_provider'] : '' );
				$url     = isset( $last['custom_tracking_link'] ) ? (string) $last['custom_tracking_link'] : '';
			}
		}
		return array( $number, $carrier, $url );
	}

	/**
	 * Sends a shipping event to Avitime.
	 *
	 * @return bool True if Avitime received it.
	 */
	public static function send_event( WC_Order $order, $type ) {
		list( $number, $carrier, $url ) = self::tracking( $order );
		$payload = array(
			'type'            => $type,
			'tracking_number' => $number,
			'carrier'         => $carrier,
			'tracking_url'    => esc_url_raw( $url ),
			'at'              => gmdate( 'c' ),
		);

		// The last « business » state is kept: adding a tracking number does not overwrite « shipped ».
		if ( 'tracking_updated' !== $type || 'created' === $order->get_meta( self::META_EVENT ) ) {
			$order->update_meta_data( self::META_EVENT, $type );
		}
		try {
			Avitime_WC_Api::from_settings()->report_order_event( $order->get_id(), $payload );
			$order->update_meta_data( self::META_PENDING, 0 );
			$ok = true;
		} catch ( Avitime_WC_Api_Exception $e ) {
			$order->update_meta_data( self::META_PENDING, 1 );
			Avitime_WC_Plugin::log( 'Event "' . $type . '" for order ' . $order->get_id() . ' not sent: ' . $e->getMessage() );
			$ok = false;
		}
		$order->save_meta_data();
		return $ok;
	}

	/** Re-sends an order whose creation could not be reported. */
	public static function resend_order( WC_Order $order ) {
		try {
			Avitime_WC_Api::from_settings()->report_order( self::order_payload( $order ) );
			$order->update_meta_data( self::META_PENDING, 0 );
			$order->save_meta_data();
			return true;
		} catch ( Avitime_WC_Api_Exception $e ) {
			Avitime_WC_Plugin::log( 'Order ' . $order->get_id() . ' still not reported: ' . $e->getMessage() );
			return false;
		}
	}

	/** @return WC_Order[] */
	public static function pending() {
		return wc_get_orders(
			array(
				'limit'      => 50,
				'meta_key'   => self::META_PENDING, // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value' => '1', // phpcs:ignore WordPress.DB.SlowDBQuery
				'type'       => 'shop_order',
			)
		);
	}

	public static function count_all() {
		$ids = wc_get_orders(
			array(
				'limit'        => -1,
				'return'       => 'ids',
				'type'         => 'shop_order',
				'meta_key'     => self::META_REF, // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_compare' => 'EXISTS',
			)
		);
		return is_array( $ids ) ? count( $ids ) : 0;
	}

	/** @return array{0:int,1:int} sent, failed */
	public static function retry_pending() {
		$sent   = 0;
		$failed = 0;
		foreach ( self::pending() as $order ) {
			$event = (string) $order->get_meta( self::META_EVENT );
			$ok    = ( '' === $event || 'created' === $event ) ? self::resend_order( $order ) : self::send_event( $order, $event );
			$ok ? ++$sent : ++$failed;
		}
		return array( $sent, $failed );
	}

	/* ------------------------------------------------------------------ */
	/* Hooks                                                               */
	/* ------------------------------------------------------------------ */

	/** Completed → shipped ; cancelled ; refunded ; « delivered » status added by some plugins. */
	public static function on_status_changed( $order_id, $from, $to, $order = null ) {
		$order = $order instanceof WC_Order ? $order : wc_get_order( $order_id );
		if ( ! self::is_avitime( $order ) ) {
			return;
		}
		$map  = array(
			'completed' => 'shipped',
			'shipped'   => 'shipped',
			'delivered' => 'delivered',
			'cancelled' => 'canceled',
			'refunded'  => 'refunded',
		);
		$type = isset( $map[ $to ] ) ? $map[ $to ] : null;
		if ( $type ) {
			self::send_event( $order, $type );
		}
	}

	/** Saves the Avitime box of the order screen (carrier, tracking number, link). */
	public static function save_tracking_box( $order_id ) {
		if ( ! isset( $_POST['avitime_tracking_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['avitime_tracking_nonce'] ) ), 'avitime_tracking' ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_shop_orders' ) ) {
			return;
		}
		$order = wc_get_order( $order_id );
		if ( ! self::is_avitime( $order ) ) {
			return;
		}
		$number  = isset( $_POST['avitime_tracking_number'] ) ? sanitize_text_field( wp_unslash( $_POST['avitime_tracking_number'] ) ) : '';
		$carrier = isset( $_POST['avitime_carrier'] ) ? sanitize_text_field( wp_unslash( $_POST['avitime_carrier'] ) ) : '';
		$url     = isset( $_POST['avitime_tracking_url'] ) ? esc_url_raw( wp_unslash( $_POST['avitime_tracking_url'] ) ) : '';
		$changed = $number !== (string) $order->get_meta( self::META_TRACKING )
			|| $carrier !== (string) $order->get_meta( self::META_CARRIER )
			|| $url !== (string) $order->get_meta( self::META_URL );
		if ( ! $changed ) {
			return;
		}
		$order->update_meta_data( self::META_TRACKING, substr( $number, 0, 80 ) );
		$order->update_meta_data( self::META_CARRIER, substr( $carrier, 0, 80 ) );
		$order->update_meta_data( self::META_URL, substr( $url, 0, 600 ) );
		$order->save_meta_data();
		if ( '' !== $number ) {
			self::send_event( $order, 'tracking_updated' );
		}
	}

	public static function cron_retry() {
		if ( Avitime_WC_Api::is_connected() ) {
			self::retry_pending();
		}
	}
}
