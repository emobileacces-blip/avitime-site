<?php
/**
 * Catalog sync: WooCommerce products → Avitime (name, price, image, stock, variations).
 *
 * @package Avitime
 */

defined( 'ABSPATH' ) || exit;

class Avitime_WC_Catalog {

	const BATCH = 50;

	/** @var int[] Products changed during this request, sent in one batch at the end. */
	protected static $queue = array();

	/** @var int[] Products deleted during this request. */
	protected static $deleted = array();

	/** @var bool */
	protected static $shutdown_hooked = false;

	/**
	 * Avitime representation of a product (same fields as the PrestaShop module).
	 *
	 * @param WC_Product|int $product Product or ID.
	 * @return array|null
	 */
	public static function build_product( $product ) {
		if ( ! $product instanceof WC_Product ) {
			$product = wc_get_product( (int) $product );
		}
		if ( ! $product || $product->is_type( 'variation' ) ) {
			return null;
		}

		$image_id = $product->get_image_id();
		$image    = $image_id ? wp_get_attachment_image_url( $image_id, 'woocommerce_single' ) : '';

		$categories = array();
		foreach ( wc_get_product_terms( $product->get_id(), 'product_cat', array( 'fields' => 'names' ) ) as $name ) {
			$categories[] = wp_strip_all_tags( (string) $name );
		}

		$combinations = array();
		if ( $product->is_type( 'variable' ) ) {
			foreach ( $product->get_children() as $variation_id ) {
				$variation = wc_get_product( $variation_id );
				if ( ! $variation || 'publish' !== $variation->get_status() ) {
					continue;
				}
				$combinations[] = array(
					'id'        => (int) $variation->get_id(),
					'name'      => self::variation_label( $variation ),
					'reference' => (string) $variation->get_sku(),
					'stock'     => self::stock( $variation ),
				);
			}
		}

		$price = (float) wc_get_price_including_tax( $product );
		if ( $price <= 0 && $product->is_type( 'variable' ) ) {
			$price = (float) $product->get_variation_price( 'min', true );
		}

		return array(
			'id'           => (int) $product->get_id(),
			'reference'    => (string) $product->get_sku(),
			'name'         => wp_strip_all_tags( $product->get_name() ),
			'active'       => 'publish' === $product->get_status(),
			'url'          => (string) get_permalink( $product->get_id() ),
			'image'        => $image ? (string) $image : '',
			'price_ttc'    => round( $price, 2 ),
			'currency'     => get_woocommerce_currency(),
			'stock'        => self::stock( $product ),
			'categories'   => $categories,
			'combinations' => $combinations,
		);
	}

	protected static function stock( WC_Product $product ) {
		$qty = $product->get_stock_quantity();
		return null === $qty ? 0 : (int) $qty;
	}

	/** « Size: M, Color: Blue » */
	protected static function variation_label( WC_Product_Variation $variation ) {
		$parts = array();
		foreach ( $variation->get_variation_attributes( false ) as $taxonomy => $value ) {
			$label = wc_attribute_label( $taxonomy, $variation );
			if ( taxonomy_exists( $taxonomy ) ) {
				$term  = get_term_by( 'slug', $value, $taxonomy );
				$value = $term ? $term->name : $value;
			}
			$parts[] = $label . ' : ' . ( '' === $value ? __( 'any', 'avitime-woocommerce' ) : $value );
		}
		return $parts ? implode( ', ', $parts ) : wp_strip_all_tags( $variation->get_name() );
	}

	/**
	 * Sends the whole catalog by batches of 50.
	 *
	 * @return int Number of products sent.
	 * @throws Avitime_WC_Api_Exception If Avitime refuses a batch.
	 */
	public static function sync_all( Avitime_WC_Api $api ) {
		$page = 1;
		$sent = 0;
		do {
			$ids = wc_get_products(
				array(
					'status'  => array( 'publish', 'private', 'draft', 'pending' ),
					'type'    => array_keys( wc_get_product_types() ),
					'limit'   => self::BATCH,
					'page'    => $page,
					'orderby' => 'ID',
					'order'   => 'ASC',
					'return'  => 'ids',
				)
			);
			$batch = array();
			foreach ( $ids as $id ) {
				$data = self::build_product( $id );
				if ( $data ) {
					$batch[] = $data;
				}
			}
			if ( $batch ) {
				$api->push_products( $batch, 20 );
				$sent += count( $batch );
			}
			++$page;
		} while ( count( $ids ) === self::BATCH );

		update_option( 'avitime_last_sync', current_time( 'mysql' ), false );
		return $sent;
	}

	/* ------------------------------------------------------------------ */
	/* Live updates (product saved / trashed / deleted)                    */
	/* ------------------------------------------------------------------ */

	public static function queue( $product_id ) {
		$product_id = (int) $product_id;
		if ( ! $product_id || ! Avitime_WC_Api::is_connected() || ( defined( 'WP_IMPORTING' ) && WP_IMPORTING ) ) {
			return;
		}
		$post_type = get_post_type( $product_id );
		if ( 'product_variation' === $post_type ) {
			$product_id = (int) wp_get_post_parent_id( $product_id );
		} elseif ( 'product' !== $post_type ) {
			return;
		}
		if ( $product_id ) {
			self::$queue[ $product_id ] = $product_id;
			self::hook_shutdown();
		}
	}

	public static function queue_delete( $post_id ) {
		if ( 'product' !== get_post_type( $post_id ) || ! Avitime_WC_Api::is_connected() ) {
			return;
		}
		self::$deleted[ (int) $post_id ] = (int) $post_id;
		unset( self::$queue[ (int) $post_id ] );
		self::hook_shutdown();
	}

	protected static function hook_shutdown() {
		if ( ! self::$shutdown_hooked ) {
			self::$shutdown_hooked = true;
			add_action( 'shutdown', array( __CLASS__, 'flush' ), 20 );
		}
	}

	/** Never slows down or blocks the product screen: errors are only logged, the full sync catches up. */
	public static function flush() {
		if ( ! self::$queue && ! self::$deleted ) {
			return;
		}
		$api = Avitime_WC_Api::from_settings();
		try {
			$batch = array();
			foreach ( self::$queue as $id ) {
				$data = self::build_product( $id );
				if ( $data ) {
					$batch[] = $data;
				}
			}
			if ( $batch ) {
				$api->push_products( $batch, 4 );
			}
		} catch ( Avitime_WC_Api_Exception $e ) {
			Avitime_WC_Plugin::log( 'Catalog update not sent: ' . $e->getMessage() );
		}
		foreach ( self::$deleted as $id ) {
			try {
				$api->delete_product( $id, 3 );
			} catch ( Avitime_WC_Api_Exception $e ) {
				Avitime_WC_Plugin::log( 'Product deletion ' . $id . ' not sent: ' . $e->getMessage() );
			}
		}
		self::$queue   = array();
		self::$deleted = array();
	}
}
