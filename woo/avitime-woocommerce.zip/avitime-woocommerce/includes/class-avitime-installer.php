<?php
/**
 * Activation: claims table and default settings.
 *
 * @package Avitime
 */

defined( 'ABSPATH' ) || exit;

class Avitime_WC_Installer {

	const DB_VERSION = '1';

	public static function claims_table() {
		global $wpdb;
		return $wpdb->prefix . 'avitime_claims';
	}

	public static function activate() {
		self::create_tables();
		add_option( 'avitime_reviews_block', 'yes' );
		add_option( 'avitime_stars', 'yes' );
		add_option( 'avitime_schema', 'yes' );
		if ( ! wp_next_scheduled( 'avitime_wc_retry' ) ) {
			wp_schedule_event( time() + 600, 'hourly', 'avitime_wc_retry' );
		}
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( 'avitime_wc_retry' );
	}

	/** Runs on every load: cheap version check, creates the table after an update. */
	public static function maybe_upgrade() {
		if ( get_option( 'avitime_db_version' ) !== self::DB_VERSION ) {
			self::create_tables();
		}
		if ( ! wp_next_scheduled( 'avitime_wc_retry' ) ) {
			wp_schedule_event( time() + 600, 'hourly', 'avitime_wc_retry' );
		}
	}

	protected static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table   = self::claims_table();
		$charset = $wpdb->get_charset_collate();
		// One row per order link: local lock so that a link can only create one order.
		dbDelta(
			"CREATE TABLE {$table} (
  token_hash char(64) NOT NULL,
  authorization_ref varchar(40) NOT NULL DEFAULT '',
  status varchar(16) NOT NULL DEFAULT 'processing',
  order_id bigint(20) unsigned NOT NULL DEFAULT 0,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (token_hash),
  KEY authorization_ref (authorization_ref)
) {$charset};"
		);
		update_option( 'avitime_db_version', self::DB_VERSION );
	}
}
