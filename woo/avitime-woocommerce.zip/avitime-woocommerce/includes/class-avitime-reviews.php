<?php
/**
 * Avitime reviews on product pages: cached fetch, HTML block, stars, structured data.
 *
 * @package Avitime
 */

defined( 'ABSPATH' ) || exit;

class Avitime_WC_Reviews {

	/** Refresh after one hour; an older copy is still shown if Avitime cannot be reached. */
	const TTL = 3600;

	public static function lang() {
		$locale = function_exists( 'determine_locale' ) ? determine_locale() : get_locale();
		$lang   = strtolower( substr( (string) $locale, 0, 2 ) );
		return preg_match( '/^[a-z]{2}$/', $lang ) ? $lang : 'fr';
	}

	protected static function cache_key( $product_id, $lang ) {
		return 'avitime_rv_' . (int) $product_id . '_' . $lang;
	}

	/**
	 * Reviews of a product (normalized), or null.
	 */
	public static function get( $product_id, $lang = null ) {
		$product_id = (int) $product_id;
		if ( ! $product_id || ! Avitime_WC_Api::is_connected() ) {
			return null;
		}
		$lang   = $lang ? $lang : self::lang();
		$key    = self::cache_key( $product_id, $lang );
		$cached = get_transient( $key );
		if ( is_array( $cached ) && isset( $cached['at'], $cached['data'] ) && $cached['at'] > time() - self::TTL ) {
			return $cached['data'];
		}
		try {
			$fresh = self::normalize( Avitime_WC_Api::from_settings()->get_product_reviews( $product_id, $lang ) );
		} catch ( Avitime_WC_Api_Exception $e ) {
			// Avitime unreachable: keep the old version instead of emptying the product page.
			return is_array( $cached ) && isset( $cached['data'] ) ? $cached['data'] : null;
		}
		set_transient(
			$key,
			array(
				'at'   => time(),
				'data' => $fresh,
			),
			WEEK_IN_SECONDS
		);
		return $fresh;
	}

	public static function forget( $product_id ) {
		foreach ( array( 'fr', 'en', 'de', 'es', 'it', 'nl', 'pt', self::lang() ) as $lang ) {
			delete_transient( self::cache_key( $product_id, $lang ) );
		}
	}

	public static function forget_all() {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_avitime\\_rv\\_%' OR option_name LIKE '\\_transient\\_timeout\\_avitime\\_rv\\_%'" );
	}

	protected static function normalize( $data ) {
		$out = array(
			'count'   => isset( $data['count'] ) ? (int) $data['count'] : 0,
			'average' => isset( $data['average'] ) ? round( (float) $data['average'], 1 ) : 0,
			'reviews' => array(),
		);
		if ( empty( $data['reviews'] ) || ! is_array( $data['reviews'] ) ) {
			return $out;
		}
		foreach ( array_slice( $data['reviews'], 0, 20 ) as $r ) {
			$media = array();
			if ( ! empty( $r['media'] ) && is_array( $r['media'] ) ) {
				foreach ( array_slice( $r['media'], 0, 4 ) as $m ) {
					if ( ! empty( $m['url'] ) && 0 === strpos( (string) $m['url'], 'https://' ) && ( ! isset( $m['type'] ) || 'image' === $m['type'] ) ) {
						$media[] = array(
							'url'   => (string) $m['url'],
							'thumb' => ! empty( $m['thumb'] ) && 0 === strpos( (string) $m['thumb'], 'https://' ) ? (string) $m['thumb'] : (string) $m['url'],
						);
					}
				}
			}
			$out['reviews'][] = array(
				'rating'         => max( 1, min( 5, isset( $r['rating'] ) ? (int) $r['rating'] : 0 ) ),
				'title'          => isset( $r['title'] ) ? (string) $r['title'] : '',
				'body'           => isset( $r['body'] ) ? (string) $r['body'] : '',
				'pros'           => isset( $r['pros'] ) ? (string) $r['pros'] : '',
				'cons'           => isset( $r['cons'] ) ? (string) $r['cons'] : '',
				'audience'       => isset( $r['audience'] ) ? (string) $r['audience'] : '',
				'recommend'      => isset( $r['recommend'] ) && null !== $r['recommend'] ? (bool) $r['recommend'] : null,
				'published_at'   => isset( $r['published_at'] ) ? substr( (string) $r['published_at'], 0, 10 ) : '',
				'usage_duration' => isset( $r['usage_duration'] ) ? (string) $r['usage_duration'] : '',
				'grade'          => isset( $r['tester']['grade'] ) ? (string) $r['tester']['grade'] : '',
				'display_name'   => isset( $r['tester']['display_name'] ) ? (string) $r['tester']['display_name'] : '',
				'media'          => $media,
				'reply'          => isset( $r['merchant_reply']['body'] ) ? (string) $r['merchant_reply']['body'] : '',
			);
		}
		return $out;
	}

	public static function notice() {
		return __( 'Product provided free for testing — verified Avitime tester', 'avitime-woocommerce' );
	}

	/* ------------------------------------------------------------------ */
	/* Rendering                                                           */
	/* ------------------------------------------------------------------ */

	public static function render_block( $product_id ) {
		$data = self::get( $product_id );
		if ( ! $data || empty( $data['reviews'] ) ) {
			return '';
		}
		wp_enqueue_style( 'avitime-front' );
		$pct = max( 0, min( 100, round( ( (float) $data['average'] ) / 5 * 100 ) ) );
		ob_start();
		include AVITIME_WC_DIR . 'templates/product-reviews.php';
		return (string) ob_get_clean();
	}

	public static function render_stars( $product_id ) {
		$data = self::get( $product_id );
		if ( ! $data || empty( $data['count'] ) ) {
			return '';
		}
		wp_enqueue_style( 'avitime-front' );
		$pct   = max( 0, min( 100, round( ( (float) $data['average'] ) / 5 * 100 ) ) );
		/* translators: %d: number of reviews. */
		$count = sprintf( _n( '%d verified review', '%d verified reviews', (int) $data['count'], 'avitime-woocommerce' ), (int) $data['count'] );
		return '<a href="#avitime-reviews" class="avt-stars-line"><span class="avt-stars" style="--avt-pct:' . (int) $pct . '%" aria-hidden="true"></span> <span>'
			. esc_html( number_format_i18n( (float) $data['average'], 1 ) ) . '/5 · ' . esc_html( $count ) . '</span></a>';
	}

	/**
	 * Adds the Avitime rating and reviews to the product data WooCommerce already prints (schema.org),
	 * unless the store already has native WooCommerce ratings. Each review states it was a free product for testing.
	 */
	public static function structured_data( $markup, $product ) {
		if ( ! is_array( $markup ) || ! $product instanceof WC_Product || ! empty( $markup['aggregateRating'] ) || 'yes' !== get_option( 'avitime_schema', 'yes' ) ) {
			return $markup;
		}
		$data = self::get( $product->get_id() );
		if ( ! $data || empty( $data['count'] ) ) {
			return $markup;
		}
		$markup['aggregateRating'] = array(
			'@type'       => 'AggregateRating',
			'ratingValue' => (float) $data['average'],
			'reviewCount' => (int) $data['count'],
			'bestRating'  => 5,
			'worstRating' => 1,
		);
		$reviews                   = array();
		foreach ( array_slice( $data['reviews'], 0, 10 ) as $r ) {
			$body = trim( $r['body'] );
			if ( $r['pros'] ) {
				$body .= "\n" . __( 'Pros:', 'avitime-woocommerce' ) . ' ' . trim( $r['pros'] );
			}
			if ( $r['cons'] ) {
				$body .= "\n" . __( 'Cons:', 'avitime-woocommerce' ) . ' ' . trim( $r['cons'] );
			}
			if ( $r['audience'] ) {
				$body .= "\n" . __( 'Ideal for:', 'avitime-woocommerce' ) . ' ' . trim( $r['audience'] );
			}
			$body  .= "\n" . self::notice() . '.';
			$review = array(
				'@type'        => 'Review',
				'author'       => array(
					'@type' => 'Person',
					'name'  => $r['display_name'] ? $r['display_name'] : __( 'Avitime tester', 'avitime-woocommerce' ),
				),
				'reviewRating' => array(
					'@type'       => 'Rating',
					'ratingValue' => (int) $r['rating'],
					'bestRating'  => 5,
					'worstRating' => 1,
				),
				'reviewBody'   => $body,
			);
			if ( $r['title'] ) {
				$review['name'] = $r['title'];
			}
			if ( $r['published_at'] ) {
				$review['datePublished'] = $r['published_at'];
			}
			foreach ( array( 'positiveNotes' => 'pros', 'negativeNotes' => 'cons' ) as $prop => $field ) {
				$items = array_values( array_filter( array_map( 'trim', preg_split( '/\r?\n|;/', (string) $r[ $field ] ) ) ) );
				if ( $items && ! in_array( strtolower( $items[0] ), array( 'aucun', 'aucune', 'rien', 'none', '-' ), true ) ) {
					$list = array(
						'@type'           => 'ItemList',
						'itemListElement' => array(),
					);
					foreach ( array_slice( $items, 0, 8 ) as $i => $text ) {
						$list['itemListElement'][] = array(
							'@type'    => 'ListItem',
							'position' => $i + 1,
							'name'     => mb_substr( $text, 0, 200 ),
						);
					}
					$review[ $prop ] = $list;
				}
			}
			$reviews[] = $review;
		}
		$markup['review'] = $reviews;
		return $markup;
	}
}
