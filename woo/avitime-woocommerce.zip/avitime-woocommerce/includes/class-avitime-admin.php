<?php
/**
 * Back office: WooCommerce → Avitime page, Avitime box on orders, orders list column.
 *
 * @package Avitime
 */

defined( 'ABSPATH' ) || exit;

class Avitime_WC_Admin {

	const PAGE = 'avitime';

	public static function menu() {
		add_submenu_page( 'woocommerce', 'Avitime', 'Avitime', 'manage_woocommerce', self::PAGE, array( __CLASS__, 'render' ) );
	}

	public static function page_url( $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => self::PAGE ), $args ), admin_url( 'admin.php' ) );
	}

	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( self::page_url() ) . '">' . esc_html__( 'Settings', 'avitime-woocommerce' ) . '</a>' );
		return $links;
	}

	/** Reminder on WooCommerce screens while the store is not connected. */
	public static function notice() {
		if ( Avitime_WC_Api::is_connected() || ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || ( false === strpos( (string) $screen->id, 'woocommerce' ) && 'plugins' !== $screen->id ) || false !== strpos( (string) $screen->id, self::PAGE ) ) {
			return;
		}
		echo '<div class="notice notice-info"><p><b>Avitime</b> — ' . esc_html__( 'Connect your store to receive your testers\' orders and show their reviews.', 'avitime-woocommerce' )
			. ' <a class="button button-primary" href="' . esc_url( self::page_url() ) . '">' . esc_html__( 'Connect to Avitime', 'avitime-woocommerce' ) . '</a></p></div>';
	}

	/* ------------------------------------------------------------------ */
	/* Settings page                                                       */
	/* ------------------------------------------------------------------ */

	/** Handles the actions of the page (runs on admin_init, before any output). */
	public static function handle() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! isset( $_GET['page'] ) || self::PAGE !== $_GET['page'] || ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		$notice = array();
		$errors = array();

		// Back from « Connect to Avitime » (the state protects this step).
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['avitime_connect_return'] ) ) {
			$state = isset( $_GET['state'] ) ? sanitize_text_field( wp_unslash( $_GET['state'] ) ) : '';
			$code  = isset( $_GET['code'] ) ? sanitize_text_field( wp_unslash( $_GET['code'] ) ) : '';
			$saved = (string) get_option( 'avitime_connect_state', '' );
			if ( ! $code || ! $state || ! $saved || ! hash_equals( $saved, $state ) ) {
				$errors[] = __( 'The connection has expired or was modified. Click « Connect to Avitime » again.', 'avitime-woocommerce' );
			} else {
				try {
					$api = new Avitime_WC_Api( Avitime_WC_Api::api_url(), '', '' );
					self::save_keys( $api->exchange_connect_code( $code, $state, home_url( '/' ) ) );
					$notice[] = __( 'Your store is connected to Avitime.', 'avitime-woocommerce' );
					$notice[] = self::sync_now();
				} catch ( Avitime_WC_Api_Exception $e ) {
					$errors[] = __( 'Connection impossible:', 'avitime-woocommerce' ) . ' ' . $e->getMessage();
				}
			}
			delete_option( 'avitime_connect_state' );
			self::redirect( $notice, $errors );
		}
		// phpcs:enable

		if ( ! isset( $_POST['avitime_action'] ) ) {
			return;
		}
		check_admin_referer( 'avitime_admin' );
		$action = sanitize_key( wp_unslash( $_POST['avitime_action'] ) );

		switch ( $action ) {
			case 'keys':
				$key    = isset( $_POST['avitime_shop_key'] ) ? sanitize_text_field( wp_unslash( $_POST['avitime_shop_key'] ) ) : '';
				$secret = isset( $_POST['avitime_shop_secret'] ) ? sanitize_text_field( wp_unslash( $_POST['avitime_shop_secret'] ) ) : '';
				if ( ! $key || ! $secret ) {
					$errors[] = __( 'Enter the key and the secret shown in your Avitime space.', 'avitime-woocommerce' );
					break;
				}
				try {
					$ping = ( new Avitime_WC_Api( Avitime_WC_Api::api_url(), $key, $secret ) )->ping();
					self::save_keys(
						array(
							'shop_key'    => $key,
							'shop_secret' => $secret,
							'shop_id'     => isset( $ping['shop_id'] ) ? $ping['shop_id'] : '',
							'shop_name'   => isset( $ping['shop_name'] ) ? $ping['shop_name'] : '',
						)
					);
					$notice[] = __( 'Key checked: your store is connected to Avitime.', 'avitime-woocommerce' );
					$notice[] = self::sync_now();
				} catch ( Avitime_WC_Api_Exception $e ) {
					$errors[] = __( 'Avitime refuses this key:', 'avitime-woocommerce' ) . ' ' . $e->getMessage();
				}
				break;

			case 'disconnect':
				foreach ( array( 'avitime_shop_key', 'avitime_shop_secret', 'avitime_shop_id', 'avitime_shop_name' ) as $option ) {
					delete_option( $option );
				}
				$notice[] = __( 'Store disconnected from Avitime.', 'avitime-woocommerce' );
				break;

			case 'settings':
				foreach ( array( 'avitime_reviews_block', 'avitime_stars', 'avitime_schema' ) as $option ) {
					update_option( $option, empty( $_POST[ $option ] ) ? 'no' : 'yes' );
				}
				foreach ( array( 'avitime_api_url', 'avitime_app_url' ) as $option ) {
					$url = isset( $_POST[ $option ] ) ? esc_url_raw( trim( wp_unslash( $_POST[ $option ] ) ) ) : '';
					if ( '' === $url ) {
						delete_option( $option );
					} elseif ( 0 === strpos( $url, 'https://' ) ) {
						update_option( $option, rtrim( $url, '/' ) );
					}
				}
				Avitime_WC_Reviews::forget_all();
				$notice[] = __( 'Settings saved.', 'avitime-woocommerce' );
				break;

			case 'sync':
				$result = self::sync_now();
				$notice[] = $result;
				break;

			case 'retry':
				list( $sent, $failed ) = Avitime_WC_Orders::retry_pending();
				/* translators: 1: sent count, 2: failed count. */
				$notice[] = sprintf( __( '%1$d sent, %2$d failed.', 'avitime-woocommerce' ), $sent, $failed );
				break;
		}
		self::redirect( $notice, $errors );
	}

	protected static function sync_now() {
		try {
			$count = Avitime_WC_Catalog::sync_all( Avitime_WC_Api::from_settings() );
			/* translators: %d: number of products. */
			return sprintf( _n( '%d product sent to Avitime.', '%d products sent to Avitime.', $count, 'avitime-woocommerce' ), $count );
		} catch ( Avitime_WC_Api_Exception $e ) {
			return __( 'Catalog sync interrupted:', 'avitime-woocommerce' ) . ' ' . $e->getMessage();
		}
	}

	protected static function save_keys( array $res ) {
		update_option( 'avitime_shop_key', isset( $res['shop_key'] ) ? (string) $res['shop_key'] : '', false );
		update_option( 'avitime_shop_secret', isset( $res['shop_secret'] ) ? (string) $res['shop_secret'] : '', false );
		update_option( 'avitime_shop_id', isset( $res['shop_id'] ) ? (string) $res['shop_id'] : '', false );
		update_option( 'avitime_shop_name', isset( $res['shop_name'] ) ? (string) $res['shop_name'] : '', false );
	}

	/** Post/redirect/get: messages are kept for the next display. */
	protected static function redirect( array $notice, array $errors ) {
		set_transient(
			'avitime_admin_msg_' . get_current_user_id(),
			array(
				'notice' => $notice,
				'errors' => $errors,
			),
			60
		);
		wp_safe_redirect( self::page_url() );
		exit;
	}

	public static function render() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		$msg = get_transient( 'avitime_admin_msg_' . get_current_user_id() );
		delete_transient( 'avitime_admin_msg_' . get_current_user_id() );
		$msg = is_array( $msg ) ? $msg : array(
			'notice' => array(),
			'errors' => array(),
		);

		$connected = Avitime_WC_Api::is_connected();
		$state     = wp_generate_password( 32, false );
		update_option( 'avitime_connect_state', $state, false );
		$connect_url = Avitime_WC_Api::app_url( '/connect/prestashop' ) . '?' . http_build_query(
			array(
				'platform'   => 'woocommerce',
				'shop_url'   => home_url( '/' ),
				'return_url' => self::page_url( array( 'avitime_connect_return' => 1 ) ),
				'state'      => $state,
			)
		);

		$ping = null;
		if ( $connected ) {
			try {
				$ping = Avitime_WC_Api::from_settings()->ping();
			} catch ( Avitime_WC_Api_Exception $e ) {
				$ping = array( 'error' => $e->getMessage() );
			}
		}
		$coming_soon = 'yes' === get_option( 'woocommerce_coming_soon', 'no' );
		$countries   = WC()->countries->get_shipping_countries();
		$checks      = array(
			array( __( 'PHP version', 'avitime-woocommerce' ), version_compare( PHP_VERSION, '7.4', '>=' ), PHP_VERSION ),
			array( __( 'WooCommerce version', 'avitime-woocommerce' ), defined( 'WC_VERSION' ) && version_compare( WC_VERSION, '7.0', '>=' ), defined( 'WC_VERSION' ) ? WC_VERSION : '?' ),
			array( __( 'Store visible to visitors', 'avitime-woocommerce' ), ! $coming_soon, $coming_soon ? __( 'no (« Coming soon » mode): testers cannot order', 'avitime-woocommerce' ) : __( 'yes', 'avitime-woocommerce' ) ),
			array( __( 'Countries you ship to', 'avitime-woocommerce' ), ! empty( $countries ), is_array( $countries ) ? (string) count( $countries ) : '0' ),
			array( __( 'Link with Avitime', 'avitime-woocommerce' ), $ping && empty( $ping['error'] ), ! $ping ? __( 'not connected', 'avitime-woocommerce' ) : ( ! empty( $ping['error'] ) ? $ping['error'] : __( 'OK', 'avitime-woocommerce' ) ) ),
		);
		$pending   = count( Avitime_WC_Orders::pending() );
		$last_sync = (string) get_option( 'avitime_last_sync', '' );
		$shop_name = (string) get_option( 'avitime_shop_name', '' );
		?>
		<div class="wrap avt-admin">
			<h1>Avitime <span style="font-size:13px;color:#646970;font-weight:400">v<?php echo esc_html( AVITIME_WC_VERSION ); ?></span></h1>
			<p style="max-width:760px"><?php esc_html_e( 'Avitime sends your products to selected testers: each one orders through a single-use link (an order at €0 is created in your store), you ship as usual, and their verified review appears on the product page with the « free product for testing » label.', 'avitime-woocommerce' ); ?></p>

			<?php foreach ( $msg['notice'] as $line ) : ?>
				<div class="notice notice-success"><p><?php echo esc_html( $line ); ?></p></div>
			<?php endforeach; ?>
			<?php foreach ( $msg['errors'] as $line ) : ?>
				<div class="notice notice-error"><p><?php echo esc_html( $line ); ?></p></div>
			<?php endforeach; ?>

			<div class="card" style="max-width:760px">
				<h2><?php esc_html_e( '1. Connection', 'avitime-woocommerce' ); ?></h2>
				<?php if ( $connected ) : ?>
					<p>✅ <?php echo esc_html( $shop_name ? sprintf( /* translators: %s: store name at Avitime. */ __( 'Connected to Avitime (%s).', 'avitime-woocommerce' ), $shop_name ) : __( 'Connected to Avitime.', 'avitime-woocommerce' ) ); ?>
						<a href="<?php echo esc_url( Avitime_WC_Api::app_url( '/commercant' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Open my Avitime space', 'avitime-woocommerce' ); ?></a></p>
					<form method="post">
						<?php wp_nonce_field( 'avitime_admin' ); ?>
						<input type="hidden" name="avitime_action" value="disconnect">
						<button class="button" onclick="return confirm('<?php echo esc_js( __( 'Disconnect this store from Avitime?', 'avitime-woocommerce' ) ); ?>')"><?php esc_html_e( 'Disconnect', 'avitime-woocommerce' ); ?></button>
					</form>
				<?php else : ?>
					<p><?php esc_html_e( 'Click the button: Avitime opens, log in to your merchant space (or create it), then authorize the connection. You come back here automatically.', 'avitime-woocommerce' ); ?></p>
					<p><a class="button button-primary button-hero" href="<?php echo esc_url( $connect_url ); ?>"><?php esc_html_e( 'Connect to Avitime', 'avitime-woocommerce' ); ?></a></p>
					<details>
						<summary><?php esc_html_e( 'Button not working? Paste a key from your Avitime space', 'avitime-woocommerce' ); ?></summary>
						<form method="post" style="margin-top:12px">
							<?php wp_nonce_field( 'avitime_admin' ); ?>
							<input type="hidden" name="avitime_action" value="keys">
							<p><label><?php esc_html_e( 'Key', 'avitime-woocommerce' ); ?><br><input class="regular-text" name="avitime_shop_key" autocomplete="off"></label></p>
							<p><label><?php esc_html_e( 'Secret', 'avitime-woocommerce' ); ?><br><input class="regular-text" type="password" name="avitime_shop_secret" autocomplete="off"></label></p>
							<p><button class="button"><?php esc_html_e( 'Check and save', 'avitime-woocommerce' ); ?></button></p>
						</form>
					</details>
				<?php endif; ?>
			</div>

			<div class="card" style="max-width:760px">
				<h2><?php esc_html_e( '2. Catalog', 'avitime-woocommerce' ); ?></h2>
				<p><?php esc_html_e( 'Your products are sent to Avitime when you connect, then each time you save a product. You choose which product to have tested in your Avitime space.', 'avitime-woocommerce' ); ?></p>
				<?php if ( $last_sync ) : ?>
					<p class="description"><?php echo esc_html( sprintf( /* translators: %s: date. */ __( 'Last full sync: %s', 'avitime-woocommerce' ), $last_sync ) ); ?></p>
				<?php endif; ?>
				<form method="post">
					<?php wp_nonce_field( 'avitime_admin' ); ?>
					<input type="hidden" name="avitime_action" value="sync">
					<button class="button" <?php disabled( ! $connected ); ?>><?php esc_html_e( 'Sync the catalog now', 'avitime-woocommerce' ); ?></button>
				</form>
			</div>

			<div class="card" style="max-width:760px">
				<h2><?php esc_html_e( '3. Tester orders', 'avitime-woocommerce' ); ?></h2>
				<p><?php esc_html_e( 'Tester orders arrive at €0 with the « Processing » status and the « Avitime » mark in your order list. Ship them as usual, enter the tracking number in the Avitime box of the order, then mark the order « Completed »: Avitime informs the tester.', 'avitime-woocommerce' ); ?></p>
				<p><?php echo esc_html( sprintf( /* translators: %d: number of orders. */ _n( '%d Avitime order in this store.', '%d Avitime orders in this store.', Avitime_WC_Orders::count_all(), 'avitime-woocommerce' ), Avitime_WC_Orders::count_all() ) ); ?></p>
				<?php if ( $pending ) : ?>
					<form method="post">
						<?php wp_nonce_field( 'avitime_admin' ); ?>
						<input type="hidden" name="avitime_action" value="retry">
						<p><?php echo esc_html( sprintf( /* translators: %d: number of orders. */ _n( '%d update could not be sent to Avitime (retried every hour).', '%d updates could not be sent to Avitime (retried every hour).', $pending, 'avitime-woocommerce' ), $pending ) ); ?>
							<button class="button"><?php esc_html_e( 'Retry now', 'avitime-woocommerce' ); ?></button></p>
					</form>
				<?php endif; ?>
			</div>

			<div class="card" style="max-width:760px">
				<h2><?php esc_html_e( '4. Reviews on your product pages', 'avitime-woocommerce' ); ?></h2>
				<form method="post">
					<?php wp_nonce_field( 'avitime_admin' ); ?>
					<input type="hidden" name="avitime_action" value="settings">
					<p><label><input type="checkbox" name="avitime_reviews_block" value="1" <?php checked( 'yes', get_option( 'avitime_reviews_block', 'yes' ) ); ?>> <?php esc_html_e( 'Show the Avitime reviews block under the product description', 'avitime-woocommerce' ); ?></label></p>
					<p><label><input type="checkbox" name="avitime_stars" value="1" <?php checked( 'yes', get_option( 'avitime_stars', 'yes' ) ); ?>> <?php esc_html_e( 'Show the average rating under the product title', 'avitime-woocommerce' ); ?></label></p>
					<p><label><input type="checkbox" name="avitime_schema" value="1" <?php checked( 'yes', get_option( 'avitime_schema', 'yes' ) ); ?>> <?php esc_html_e( 'Add the rating to the product data read by Google and AI assistants (schema.org)', 'avitime-woocommerce' ); ?></label></p>
					<p class="description"><?php esc_html_e( 'The block stays hidden until a product has reviews. Theme or page builder without the usual WooCommerce areas? Use the shortcodes [avitime_reviews] and [avitime_stars].', 'avitime-woocommerce' ); ?></p>
					<details style="margin:10px 0">
						<summary><?php esc_html_e( 'Advanced (Avitime support only)', 'avitime-woocommerce' ); ?></summary>
						<p><label><?php esc_html_e( 'API address', 'avitime-woocommerce' ); ?><br><input class="regular-text" name="avitime_api_url" value="<?php echo esc_attr( (string) get_option( 'avitime_api_url', '' ) ); ?>" placeholder="<?php echo esc_attr( Avitime_WC_Api::DEFAULT_API_URL ); ?>"></label></p>
						<p><label><?php esc_html_e( 'Avitime address', 'avitime-woocommerce' ); ?><br><input class="regular-text" name="avitime_app_url" value="<?php echo esc_attr( (string) get_option( 'avitime_app_url', '' ) ); ?>" placeholder="<?php echo esc_attr( Avitime_WC_Api::DEFAULT_APP_URL ); ?>"></label></p>
					</details>
					<p><button class="button button-primary"><?php esc_html_e( 'Save', 'avitime-woocommerce' ); ?></button></p>
				</form>
			</div>

			<div class="card" style="max-width:760px">
				<h2><?php esc_html_e( 'Checks', 'avitime-woocommerce' ); ?></h2>
				<table class="widefat striped" style="border:0">
					<?php foreach ( $checks as $check ) : ?>
						<tr><td><?php echo $check[1] ? '✅' : '⚠️'; ?> <?php echo esc_html( $check[0] ); ?></td><td><?php echo esc_html( $check[2] ); ?></td></tr>
					<?php endforeach; ?>
				</table>
				<p class="description"><?php esc_html_e( 'Help: contact@avitime.fr', 'avitime-woocommerce' ); ?></p>
			</div>
		</div>
		<?php
	}

	/* ------------------------------------------------------------------ */
	/* Orders                                                              */
	/* ------------------------------------------------------------------ */

	public static function order_screen_id() {
		if ( function_exists( 'wc_get_page_screen_id' ) ) {
			return wc_get_page_screen_id( 'shop-order' );
		}
		return 'shop_order';
	}

	public static function add_meta_box( $post_type = '', $post_or_order = null ) {
		$order = $post_or_order instanceof WC_Order ? $post_or_order : ( $post_or_order instanceof WP_Post ? wc_get_order( $post_or_order->ID ) : null );
		if ( $order && ! Avitime_WC_Orders::is_avitime( $order ) ) {
			return;
		}
		add_meta_box( 'avitime-order', 'Avitime', array( __CLASS__, 'render_meta_box' ), self::order_screen_id(), 'side', 'high' );
	}

	public static function render_meta_box( $post_or_order ) {
		$order = $post_or_order instanceof WC_Order ? $post_or_order : wc_get_order( $post_or_order->ID );
		if ( ! Avitime_WC_Orders::is_avitime( $order ) ) {
			echo '<p>' . esc_html__( 'Not an Avitime tester order.', 'avitime-woocommerce' ) . '</p>';
			return;
		}
		$events  = array(
			'created'          => __( 'Order created, to ship', 'avitime-woocommerce' ),
			'shipped'          => __( 'Shipped', 'avitime-woocommerce' ),
			'tracking_updated' => __( 'Tracking sent to Avitime', 'avitime-woocommerce' ),
			'delivered'        => __( 'Delivered: the test has started', 'avitime-woocommerce' ),
			'canceled'         => __( 'Cancelled: incident opened at Avitime', 'avitime-woocommerce' ),
			'refunded'         => __( 'Refunded: incident opened at Avitime', 'avitime-woocommerce' ),
		);
		$event   = (string) $order->get_meta( Avitime_WC_Orders::META_EVENT );
		$pending = (bool) $order->get_meta( Avitime_WC_Orders::META_PENDING );
		wp_nonce_field( 'avitime_tracking', 'avitime_tracking_nonce' );
		?>
		<p style="background:#fff7f1;border:1px solid #ff6a13;border-radius:6px;padding:8px"><b>★ <?php esc_html_e( 'Avitime tester order', 'avitime-woocommerce' ); ?></b><br>
			<?php esc_html_e( 'Product provided free for testing: ship it as usual, do not cancel or refund it.', 'avitime-woocommerce' ); ?></p>
		<p><?php esc_html_e( 'Mission', 'avitime-woocommerce' ); ?> : <b><?php echo esc_html( (string) $order->get_meta( Avitime_WC_Orders::META_MISSION ) ); ?></b><br>
			<?php esc_html_e( 'Authorization', 'avitime-woocommerce' ); ?> : <?php echo esc_html( (string) $order->get_meta( Avitime_WC_Orders::META_REF ) ); ?><br>
			<?php esc_html_e( 'Status at Avitime', 'avitime-woocommerce' ); ?> : <?php echo esc_html( isset( $events[ $event ] ) ? $events[ $event ] : $event ); ?>
			<?php if ( $pending ) : ?><br><span style="color:#b32d2e">⚠ <?php esc_html_e( 'Not yet received by Avitime (retried every hour).', 'avitime-woocommerce' ); ?></span><?php endif; ?></p>
		<p><label><?php esc_html_e( 'Carrier', 'avitime-woocommerce' ); ?><br><input type="text" name="avitime_carrier" style="width:100%" value="<?php echo esc_attr( (string) $order->get_meta( Avitime_WC_Orders::META_CARRIER ) ); ?>" placeholder="Colissimo"></label></p>
		<p><label><?php esc_html_e( 'Tracking number', 'avitime-woocommerce' ); ?><br><input type="text" name="avitime_tracking_number" style="width:100%" value="<?php echo esc_attr( (string) $order->get_meta( Avitime_WC_Orders::META_TRACKING ) ); ?>"></label></p>
		<p><label><?php esc_html_e( 'Tracking link (optional)', 'avitime-woocommerce' ); ?><br><input type="url" name="avitime_tracking_url" style="width:100%" value="<?php echo esc_attr( (string) $order->get_meta( Avitime_WC_Orders::META_URL ) ); ?>"></label></p>
		<p class="description"><?php esc_html_e( 'Saved with the order (« Update » button). Then mark the order « Completed » when it has shipped.', 'avitime-woocommerce' ); ?></p>
		<?php
	}

	public static function add_column( $columns ) {
		$out = array();
		foreach ( $columns as $key => $label ) {
			$out[ $key ] = $label;
			if ( 'order_number' === $key ) {
				$out['avitime'] = 'Avitime';
			}
		}
		if ( ! isset( $out['avitime'] ) ) {
			$out['avitime'] = 'Avitime';
		}
		return $out;
	}

	/** HPOS: ($column, $order) ; posts storage: ($column, $post_id). */
	public static function render_column( $column, $order_or_id ) {
		if ( 'avitime' !== $column ) {
			return;
		}
		$order = $order_or_id instanceof WC_Order ? $order_or_id : wc_get_order( (int) $order_or_id );
		if ( Avitime_WC_Orders::is_avitime( $order ) ) {
			echo '<mark class="order-status" style="background:#ffe6d6;color:#8a3300"><span>★ ' . esc_html__( 'Avitime tester', 'avitime-woocommerce' ) . '</span></mark>';
		}
	}
}
