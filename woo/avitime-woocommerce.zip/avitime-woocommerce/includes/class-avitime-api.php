<?php
/**
 * HTTP client for the Avitime API (same contract as the PrestaShop module).
 *
 * Signature: hex(HMAC-SHA256(secret, timestamp \n METHOD \n path?query \n hex(SHA256(body)))).
 *
 * @package Avitime
 */

defined( 'ABSPATH' ) || exit;

class Avitime_WC_Api_Exception extends Exception {

	/** @var int HTTP status (0 = network). */
	public $status = 0;

	/** @var string Machine code returned by Avitime. */
	public $error_code = '';

	public function __construct( $message, $status = 0, $error_code = '' ) {
		parent::__construct( (string) $message );
		$this->status     = (int) $status;
		$this->error_code = (string) $error_code;
	}
}

class Avitime_WC_Api {

	const DEFAULT_API_URL = 'https://api.avitime.fr/v1';
	const DEFAULT_APP_URL = 'https://app.avitime.fr';
	/** Fixed path used to sign webhooks, shared by every Avitime store integration. */
	const WEBHOOK_PATH    = '/module/avitime/webhook';
	const MAX_CLOCK_SKEW  = 300;

	/** @var string */
	protected $base_url;

	/** @var string */
	protected $key;

	/** @var string */
	protected $secret;

	public function __construct( $base_url, $key, $secret ) {
		$this->base_url = rtrim( (string) $base_url, '/' );
		$this->key      = (string) $key;
		$this->secret   = (string) $secret;
	}

	/**
	 * Client built from the saved settings.
	 *
	 * @return Avitime_WC_Api
	 */
	public static function from_settings() {
		return new self( self::api_url(), get_option( 'avitime_shop_key', '' ), get_option( 'avitime_shop_secret', '' ) );
	}

	public static function api_url() {
		$url = (string) get_option( 'avitime_api_url', '' );
		return $url ? rtrim( $url, '/' ) : self::DEFAULT_API_URL;
	}

	public static function app_url( $path = '' ) {
		$url = (string) get_option( 'avitime_app_url', '' );
		return ( $url ? rtrim( $url, '/' ) : self::DEFAULT_APP_URL ) . $path;
	}

	public static function is_connected() {
		return (bool) ( get_option( 'avitime_shop_key', '' ) && get_option( 'avitime_shop_secret', '' ) );
	}

	/* ------------------------------------------------------------------ */
	/* Routes                                                              */
	/* ------------------------------------------------------------------ */

	public function ping() {
		return $this->request( 'GET', '/shop/ping' );
	}

	public function exchange_connect_code( $code, $state, $shop_url ) {
		return $this->request(
			'POST',
			'/connect/exchange',
			array(
				'code'           => (string) $code,
				'state'          => (string) $state,
				'shop_url'       => (string) $shop_url,
				'platform'       => 'woocommerce',
				'ps_version'     => self::platform_version(),
				'module_version' => AVITIME_WC_VERSION,
			),
			false
		);
	}

	public function push_products( array $products, $timeout = 8 ) {
		return $this->request( 'PUT', '/catalog/products', array( 'products' => array_values( $products ) ), true, $timeout );
	}

	public function delete_product( $product_id, $timeout = 8 ) {
		return $this->request( 'DELETE', '/catalog/products/' . (int) $product_id, null, true, $timeout );
	}

	public function verify_authorization( $token ) {
		return $this->request( 'POST', '/authorizations/verify', array( 'token' => (string) $token ) );
	}

	public function consume_authorization( $token, $authorization_ref, $order_id ) {
		return $this->request(
			'POST',
			'/authorizations/consume',
			array(
				'token'             => (string) $token,
				'authorization_ref' => (string) $authorization_ref,
				'cart_id'           => (int) $order_id,
				'total_paid'        => 0,
			)
		);
	}

	public function report_order( array $payload ) {
		return $this->request( 'POST', '/orders', $payload );
	}

	public function report_order_event( $order_id, array $payload ) {
		return $this->request( 'POST', '/orders/' . (int) $order_id . '/events', $payload );
	}

	public function get_product_reviews( $product_id, $lang ) {
		return $this->request( 'GET', '/products/' . (int) $product_id . '/reviews?lang=' . rawurlencode( (string) $lang ), null, true, 4 );
	}

	/* ------------------------------------------------------------------ */
	/* Signature                                                           */
	/* ------------------------------------------------------------------ */

	public static function sign( $secret, $timestamp, $method, $path_with_query, $body ) {
		$canonical = $timestamp . "\n" . strtoupper( $method ) . "\n" . $path_with_query . "\n" . hash( 'sha256', (string) $body );
		return hash_hmac( 'sha256', $canonical, (string) $secret );
	}

	/**
	 * Checks a webhook sent by Avitime.
	 */
	public static function verify_webhook( $secret, $timestamp, $signature, $body ) {
		if ( ! $secret || ! ctype_digit( (string) $timestamp ) || abs( time() - (int) $timestamp ) > self::MAX_CLOCK_SKEW ) {
			return false;
		}
		$expected = self::sign( $secret, $timestamp, 'POST', self::WEBHOOK_PATH, $body );
		return hash_equals( $expected, strtolower( (string) $signature ) );
	}

	public static function platform_version() {
		$wc = defined( 'WC_VERSION' ) ? WC_VERSION : '?';
		return substr( 'WooCommerce ' . $wc . ' / WP ' . get_bloginfo( 'version' ), 0, 40 );
	}

	/* ------------------------------------------------------------------ */
	/* Transport                                                           */
	/* ------------------------------------------------------------------ */

	/**
	 * @return array Decoded JSON answer.
	 * @throws Avitime_WC_Api_Exception On network or API error.
	 */
	protected function request( $method, $path, $data = null, $signed = true, $timeout = 8 ) {
		if ( $signed && ( ! $this->key || ! $this->secret ) ) {
			throw new Avitime_WC_Api_Exception( __( 'This store is not connected to Avitime.', 'avitime-woocommerce' ), 0, 'not_connected' );
		}

		$url             = $this->base_url . $path;
		$body            = null === $data ? '' : wp_json_encode( $data );
		$parts           = wp_parse_url( $url );
		$path_with_query = ( isset( $parts['path'] ) ? $parts['path'] : '/' ) . ( isset( $parts['query'] ) ? '?' . $parts['query'] : '' );

		$headers = array(
			'Accept'           => 'application/json',
			'X-Avitime-Module' => AVITIME_WC_VERSION,
			'X-Avitime-PS'     => self::platform_version(),
		);
		if ( '' !== $body ) {
			$headers['Content-Type'] = 'application/json';
		}
		if ( $signed ) {
			$ts                             = (string) time();
			$headers['X-Avitime-Key']       = $this->key;
			$headers['X-Avitime-Timestamp'] = $ts;
			$headers['X-Avitime-Signature'] = self::sign( $this->secret, $ts, $method, $path_with_query, $body );
		}

		$response = wp_remote_request(
			$url,
			array(
				'method'      => strtoupper( $method ),
				'headers'     => $headers,
				'body'        => '' === $body ? null : $body,
				'timeout'     => (int) $timeout,
				'redirection' => 0,
				'sslverify'   => true,
				'user-agent'  => 'Avitime-WooCommerce/' . AVITIME_WC_VERSION,
			)
		);

		if ( is_wp_error( $response ) ) {
			/* translators: %s: technical error message. */
			throw new Avitime_WC_Api_Exception( sprintf( __( 'Avitime cannot be reached (%s).', 'avitime-woocommerce' ), $response->get_error_message() ), 0, 'network' );
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$raw    = (string) wp_remote_retrieve_body( $response );
		$json   = '' === $raw ? array() : json_decode( $raw, true );

		if ( $status >= 400 ) {
			$code = is_array( $json ) && isset( $json['error'] ) ? (string) $json['error'] : 'http_' . $status;
			/* translators: %d: HTTP status code. */
			$message = is_array( $json ) && isset( $json['message'] ) ? (string) $json['message'] : sprintf( __( 'Avitime error (%d).', 'avitime-woocommerce' ), $status );
			throw new Avitime_WC_Api_Exception( $message, $status, $code );
		}
		if ( '' !== $raw && ! is_array( $json ) ) {
			throw new Avitime_WC_Api_Exception( __( 'Unreadable answer from Avitime.', 'avitime-woocommerce' ), $status, 'bad_response' );
		}

		return is_array( $json ) ? $json : array();
	}
}
