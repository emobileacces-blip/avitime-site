<?php
/**
 * Public side: tester order page, Avitime webhook, reviews on product pages.
 *
 * Avitime calls the same addresses as for PrestaShop, which WordPress answers too:
 *   /index.php?fc=module&module=avitime&controller=claim&t=…   (tester order page)
 *   /index.php?fc=module&module=avitime&controller=webhook       (notifications)
 * and the shorter /?avitime=claim&t=… / /?avitime=webhook.
 *
 * @package Avitime
 */

defined( 'ABSPATH' ) || exit;

class Avitime_WC_Front {

	const CSRF_COOKIE = 'avitime_csrf';

	/** Which Avitime page is asked for, if any. */
	public static function route() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['fc'], $_GET['module'], $_GET['controller'] ) && 'module' === $_GET['fc'] && 'avitime' === $_GET['module'] ) {
			$controller = sanitize_key( wp_unslash( $_GET['controller'] ) );
		} elseif ( isset( $_GET['avitime'] ) ) {
			$controller = sanitize_key( wp_unslash( $_GET['avitime'] ) );
		} else {
			return '';
		}
		// phpcs:enable
		return in_array( $controller, array( 'claim', 'webhook' ), true ) ? $controller : '';
	}

	/** Runs on « wp_loaded », before WordPress resolves the page (no redirect, no theme). */
	public static function dispatch() {
		$route = self::route();
		if ( 'webhook' === $route ) {
			self::webhook();
		} elseif ( 'claim' === $route ) {
			self::claim();
		}
	}

	/* ------------------------------------------------------------------ */
	/* Webhook                                                             */
	/* ------------------------------------------------------------------ */

	protected static function reply( $status, array $data ) {
		status_header( (int) $status );
		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		echo wp_json_encode( $data );
		exit;
	}

	public static function webhook() {
		if ( ! isset( $_SERVER['REQUEST_METHOD'] ) || 'POST' !== $_SERVER['REQUEST_METHOD'] ) {
			self::reply( 405, array( 'error' => 'method_not_allowed' ) );
		}
		$body = (string) file_get_contents( 'php://input' );
		if ( strlen( $body ) > 65536 ) {
			self::reply( 413, array( 'error' => 'too_large' ) );
		}
		$timestamp = isset( $_SERVER['HTTP_X_AVITIME_TIMESTAMP'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_AVITIME_TIMESTAMP'] ) ) : '';
		$signature = isset( $_SERVER['HTTP_X_AVITIME_SIGNATURE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_AVITIME_SIGNATURE'] ) ) : '';
		$secret    = (string) get_option( 'avitime_shop_secret', '' );
		if ( ! $secret ) {
			self::reply( 503, array( 'error' => 'not_connected' ) );
		}
		if ( ! Avitime_WC_Api::verify_webhook( $secret, $timestamp, $signature, $body ) ) {
			self::reply( 401, array( 'error' => 'bad_signature' ) );
		}
		$payload = json_decode( $body, true );
		if ( ! is_array( $payload ) || empty( $payload['event'] ) ) {
			self::reply( 400, array( 'error' => 'bad_payload' ) );
		}
		$data = isset( $payload['data'] ) && is_array( $payload['data'] ) ? $payload['data'] : array();

		switch ( (string) $payload['event'] ) {
			case 'ping':
				self::reply(
					200,
					array(
						'ok'     => true,
						'module' => AVITIME_WC_VERSION,
						'ps'     => Avitime_WC_Api::platform_version(),
					)
				);
				break;
			case 'review.published':
			case 'review.updated':
			case 'review.removed':
				if ( ! empty( $data['product_id'] ) ) {
					Avitime_WC_Reviews::forget( (int) $data['product_id'] );
				}
				self::reply( 200, array( 'ok' => true ) );
				break;
			case 'authorization.revoked':
				if ( ! empty( $data['authorization_ref'] ) ) {
					self::revoke( (string) $data['authorization_ref'] );
				}
				self::reply( 200, array( 'ok' => true ) );
				break;
			default:
				self::reply(
					200,
					array(
						'ok'      => true,
						'ignored' => true,
					)
				);
		}
	}

	protected static function revoke( $ref ) {
		global $wpdb;
		$table = Avitime_WC_Installer::claims_table();
		$ref   = substr( $ref, 0, 40 );
		$now   = current_time( 'mysql', true );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$known = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE authorization_ref = %s", $ref ) );
		if ( ! $known ) {
			$wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$table} (token_hash, authorization_ref, status, order_id, created_at, updated_at) VALUES (%s, %s, 'revoked', 0, %s, %s)", hash( 'sha256', 'revoked:' . $ref ), $ref, $now, $now ) );
		}
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET status = 'revoked', updated_at = %s WHERE authorization_ref = %s AND status IN ('processing', 'failed')", $now, $ref ) );
		// phpcs:enable
	}

	/* ------------------------------------------------------------------ */
	/* Tester order page                                                   */
	/* ------------------------------------------------------------------ */

	protected static function csrf_token() {
		if ( ! empty( $_COOKIE[ self::CSRF_COOKIE ] ) && preg_match( '/^[a-f0-9]{32}$/', sanitize_text_field( wp_unslash( $_COOKIE[ self::CSRF_COOKIE ] ) ) ) ) {
			return sanitize_text_field( wp_unslash( $_COOKIE[ self::CSRF_COOKIE ] ) );
		}
		$token = bin2hex( random_bytes( 16 ) );
		setcookie(
			self::CSRF_COOKIE,
			$token,
			array(
				'expires'  => time() + DAY_IN_SECONDS,
				'path'     => COOKIEPATH ? COOKIEPATH : '/',
				'secure'   => is_ssl(),
				'httponly' => true,
				'samesite' => 'Lax',
			)
		);
		return $token;
	}

	public static function claim() {
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		nocache_headers();
		header( 'Referrer-Policy: no-referrer' );
		header( 'X-Robots-Tag: noindex, nofollow' );

		// phpcs:disable WordPress.Security.NonceVerification -- protected by the csrf cookie below and by the one-time link.
		$token = isset( $_REQUEST['t'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['t'] ) ) : '';
		$vars  = array(
			'error'       => null,
			'done'        => null,
			'item'        => null,
			'form'        => array(),
			'form_errors' => array(),
			'countries'   => array(),
			'token'       => $token,
			'csrf'        => self::csrf_token(),
			'action'      => add_query_arg( 'avitime', 'claim', home_url( '/' ) ),
		);
		$service = new Avitime_WC_Claim( Avitime_WC_Api::from_settings() );

		try {
			if ( ! Avitime_WC_Api::is_connected() ) {
				throw new Avitime_WC_Claim_Exception( __( 'This store is not connected to Avitime yet. Contact Avitime from your tester space.', 'avitime-woocommerce' ) );
			}
			$auth         = $service->verify( $token );
			$vars['item'] = $service->present( $auth );
			$form         = $service->default_form( $auth );

			if ( isset( $_POST['avitime_confirm'] ) ) {
				$sent = isset( $_POST['avt_csrf'] ) ? sanitize_text_field( wp_unslash( $_POST['avt_csrf'] ) ) : '';
				if ( ! hash_equals( $vars['csrf'], $sent ) ) {
					throw new Avitime_WC_Claim_Exception( __( 'The page has expired. Reload it and confirm again.', 'avitime-woocommerce' ) );
				}
				foreach ( array_keys( $form ) as $field ) {
					$form[ $field ] = isset( $_POST[ 'avt_' . $field ] ) ? trim( sanitize_text_field( wp_unslash( $_POST[ 'avt_' . $field ] ) ) ) : '';
				}
				$form['country_iso']  = strtoupper( $form['country_iso'] );
				$vars['form_errors'] = $service->validate_form( $form );
				if ( ! $vars['form_errors'] ) {
					$order        = $service->place_order( $token, $auth, $form );
					$vars['done'] = array(
						'reference' => $order->get_order_number(),
						'firstname' => $form['firstname'],
					);
				}
			}
			$vars['form']      = $form;
			$vars['countries'] = Avitime_WC_Claim::countries();
		} catch ( Avitime_WC_Claim_Exception $e ) {
			$vars['error'] = $e->getMessage();
		}
		// phpcs:enable

		status_header( 200 );
		header( 'Content-Type: text/html; charset=utf-8' );
		$avt = $vars;
		include AVITIME_WC_DIR . 'templates/claim.php';
		exit;
	}

	/* ------------------------------------------------------------------ */
	/* Product page                                                        */
	/* ------------------------------------------------------------------ */

	public static function register_assets() {
		wp_register_style( 'avitime-front', AVITIME_WC_URL . 'assets/front.css', array(), AVITIME_WC_VERSION );
		if ( function_exists( 'is_product' ) && is_product() && ( 'yes' === get_option( 'avitime_reviews_block', 'yes' ) || 'yes' === get_option( 'avitime_stars', 'yes' ) ) ) {
			wp_enqueue_style( 'avitime-front' );
		}
	}

	public static function product_reviews() {
		global $product;
		if ( 'yes' !== get_option( 'avitime_reviews_block', 'yes' ) || ! $product instanceof WC_Product ) {
			return;
		}
		echo Avitime_WC_Reviews::render_block( $product->get_id() ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in the template.
	}

	public static function product_stars() {
		global $product;
		if ( 'yes' !== get_option( 'avitime_stars', 'yes' ) || ! $product instanceof WC_Product ) {
			return;
		}
		echo Avitime_WC_Reviews::render_stars( $product->get_id() ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in render_stars().
	}

	/** [avitime_reviews] or [avitime_reviews product="123"], for themes and page builders without the usual hooks. */
	public static function shortcode( $atts ) {
		$atts = shortcode_atts( array( 'product' => 0 ), $atts, 'avitime_reviews' );
		$id   = (int) $atts['product'];
		if ( ! $id ) {
			global $product;
			$id = $product instanceof WC_Product ? $product->get_id() : (int) get_the_ID();
		}
		return $id ? Avitime_WC_Reviews::render_block( $id ) : '';
	}

	/** [avitime_stars] */
	public static function shortcode_stars( $atts ) {
		$atts = shortcode_atts( array( 'product' => 0 ), $atts, 'avitime_stars' );
		$id   = (int) $atts['product'];
		if ( ! $id ) {
			global $product;
			$id = $product instanceof WC_Product ? $product->get_id() : (int) get_the_ID();
		}
		return $id ? Avitime_WC_Reviews::render_stars( $id ) : '';
	}
}
