<?php
/**
 * Turns an Avitime order link into a real €0 WooCommerce order.
 *
 * Every step is checked on the server: token, status, product, quantity, stock, €0 total,
 * atomic consumption of the token at Avitime, then the order.
 *
 * @package Avitime
 */

defined( 'ABSPATH' ) || exit;

class Avitime_WC_Claim_Exception extends Exception {
}

class Avitime_WC_Claim {

	const MAX_QUANTITY  = 5;
	const PAYMENT_ID    = 'avitime';

	/** @var Avitime_WC_Api */
	protected $api;

	public function __construct( Avitime_WC_Api $api ) {
		$this->api = $api;
	}

	public static function hash_token( $token ) {
		return hash( 'sha256', (string) $token );
	}

	public static function payment_label() {
		return __( 'Avitime – free product for testing', 'avitime-woocommerce' );
	}

	/* ------------------------------------------------------------------ */
	/* 1. Link check                                                       */
	/* ------------------------------------------------------------------ */

	/**
	 * @return array Authorization returned by Avitime, with the « _product » object.
	 * @throws Avitime_WC_Claim_Exception If the link cannot be used.
	 */
	public function verify( $token ) {
		global $wpdb;
		if ( ! is_string( $token ) || ! preg_match( '/^[A-Za-z0-9_-]{24,128}$/', $token ) ) {
			throw new Avitime_WC_Claim_Exception( __( 'This order link is not valid. Check that you copied it entirely.', 'avitime-woocommerce' ) );
		}
		$table = Avitime_WC_Installer::claims_table();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$local = $wpdb->get_row( $wpdb->prepare( "SELECT status, order_id FROM {$table} WHERE token_hash = %s", self::hash_token( $token ) ), ARRAY_A );
		if ( $local && 'used' === $local['status'] ) {
			throw new Avitime_WC_Claim_Exception( __( 'This link has already been used: your order is registered. You will follow its shipping from your Avitime tester space.', 'avitime-woocommerce' ) );
		}
		if ( $local && 'revoked' === $local['status'] ) {
			throw new Avitime_WC_Claim_Exception( __( 'This link is no longer valid. Your mission was cancelled or replaced.', 'avitime-woocommerce' ) );
		}

		try {
			$auth = $this->api->verify_authorization( $token );
		} catch ( Avitime_WC_Api_Exception $e ) {
			if ( 404 === $e->status ) {
				throw new Avitime_WC_Claim_Exception( __( 'This order link is unknown. Check that you copied it entirely.', 'avitime-woocommerce' ) );
			}
			Avitime_WC_Plugin::log( 'Link check impossible: ' . $e->getMessage() );
			throw new Avitime_WC_Claim_Exception( __( 'Avitime cannot be reached right now. Try again in a few minutes.', 'avitime-woocommerce' ) );
		}

		$status = isset( $auth['status'] ) ? $auth['status'] : '';
		if ( 'used' === $status ) {
			throw new Avitime_WC_Claim_Exception( __( 'This link has already been used: your order is registered.', 'avitime-woocommerce' ) );
		}
		if ( 'expired' === $status ) {
			throw new Avitime_WC_Claim_Exception( __( 'This link has expired. Contact Avitime from your tester space.', 'avitime-woocommerce' ) );
		}
		if ( 'valid' !== $status ) {
			throw new Avitime_WC_Claim_Exception( __( 'This link is no longer valid.', 'avitime-woocommerce' ) );
		}
		if ( empty( $auth['authorization_ref'] ) || empty( $auth['product']['id'] ) || empty( $auth['tester']['email'] ) ) {
			throw new Avitime_WC_Claim_Exception( __( 'The details of this link are incomplete. Contact Avitime.', 'avitime-woocommerce' ) );
		}
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$revoked = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE authorization_ref = %s AND status = 'revoked'", (string) $auth['authorization_ref'] ) );
		if ( $revoked ) {
			throw new Avitime_WC_Claim_Exception( __( 'This link is no longer valid. Your mission was cancelled or replaced.', 'avitime-woocommerce' ) );
		}

		$product_id   = (int) $auth['product']['id'];
		$variation_id = isset( $auth['product']['combination_id'] ) ? (int) $auth['product']['combination_id'] : 0;
		$quantity     = isset( $auth['product']['quantity'] ) ? (int) $auth['product']['quantity'] : 1;
		if ( $quantity < 1 || $quantity > self::MAX_QUANTITY ) {
			throw new Avitime_WC_Claim_Exception( __( 'The quantity planned for this link is not valid.', 'avitime-woocommerce' ) );
		}

		$product = wc_get_product( $product_id );
		if ( ! $product || $product->is_type( 'variation' ) || 'publish' !== $product->get_status() ) {
			throw new Avitime_WC_Claim_Exception( __( 'This product is no longer available in the store. Avitime has been notified.', 'avitime-woocommerce' ) );
		}
		$item = $product;
		if ( $product->is_type( 'variable' ) ) {
			$variation = $variation_id ? wc_get_product( $variation_id ) : null;
			if ( ! $variation || ! $variation->is_type( 'variation' ) || (int) $variation->get_parent_id() !== $product_id || 'publish' !== $variation->get_status() ) {
				throw new Avitime_WC_Claim_Exception( __( 'The variation planned for this product no longer exists. Avitime has been notified.', 'avitime-woocommerce' ) );
			}
			$item = $variation;
		} else {
			$variation_id = 0;
		}
		if ( ! $item->is_in_stock() || ! $item->has_enough_stock( $quantity ) ) {
			throw new Avitime_WC_Claim_Exception( __( 'This product is out of stock for now. Your link remains valid: try again later.', 'avitime-woocommerce' ) );
		}

		$auth['product']['combination_id'] = $variation_id;
		$auth['product']['quantity']       = $quantity;
		$auth['_product']                  = $item;
		return $auth;
	}

	/** Display data for the order page. */
	public function present( array $auth ) {
		/** @var WC_Product $item */
		$item     = $auth['_product'];
		$image_id = $item->get_image_id();
		$expires  = isset( $auth['expires_at'] ) ? substr( (string) $auth['expires_at'], 0, 10 ) : '';
		return array(
			'name'              => wp_strip_all_tags( $item->get_name() ),
			'image'             => $image_id ? (string) wp_get_attachment_image_url( $image_id, 'woocommerce_thumbnail' ) : '',
			'quantity'          => (int) $auth['product']['quantity'],
			'authorization_ref' => (string) $auth['authorization_ref'],
			'mission_ref'       => isset( $auth['mission_ref'] ) ? (string) $auth['mission_ref'] : '',
			'expires_at'        => $expires,
		);
	}

	/* ------------------------------------------------------------------ */
	/* 2. Shipping address                                                 */
	/* ------------------------------------------------------------------ */

	public function default_form( array $auth ) {
		$t = $auth['tester'];
		$a = isset( $t['address'] ) && is_array( $t['address'] ) ? $t['address'] : array();
		return array(
			'firstname'   => isset( $t['firstname'] ) ? (string) $t['firstname'] : '',
			'lastname'    => isset( $t['lastname'] ) ? (string) $t['lastname'] : '',
			'address1'    => isset( $a['address1'] ) ? (string) $a['address1'] : '',
			'address2'    => isset( $a['address2'] ) ? (string) $a['address2'] : '',
			'postcode'    => isset( $a['postcode'] ) ? (string) $a['postcode'] : '',
			'city'        => isset( $a['city'] ) ? (string) $a['city'] : '',
			'country_iso' => isset( $a['country_iso'] ) ? strtoupper( (string) $a['country_iso'] ) : 'FR',
			'phone'       => isset( $a['phone'] ) ? (string) $a['phone'] : '',
		);
	}

	/** @return array<string,string> Countries the store ships to. */
	public static function countries() {
		$countries = WC()->countries->get_shipping_countries();
		return is_array( $countries ) ? $countries : array();
	}

	/** @return string[] Errors by field (empty when everything is fine). */
	public function validate_form( array $form ) {
		$errors = array();
		foreach ( array( 'firstname' => __( 'First name', 'avitime-woocommerce' ), 'lastname' => __( 'Last name', 'avitime-woocommerce' ) ) as $field => $label ) {
			if ( '' === $form[ $field ] || mb_strlen( $form[ $field ] ) > 60 || preg_match( '/[0-9!<>,;?=+()@#"°{}_$%:]/u', $form[ $field ] ) ) {
				/* translators: %s: field label. */
				$errors[ $field ] = sprintf( __( '%s: enter a valid name (letters, spaces, hyphens).', 'avitime-woocommerce' ), $label );
			}
		}
		if ( '' === $form['address1'] || mb_strlen( $form['address1'] ) > 128 ) {
			$errors['address1'] = __( 'Address: enter the number and the street.', 'avitime-woocommerce' );
		}
		if ( mb_strlen( $form['address2'] ) > 128 ) {
			$errors['address2'] = __( 'Address line 2 is not valid.', 'avitime-woocommerce' );
		}
		if ( '' === $form['city'] || mb_strlen( $form['city'] ) > 64 ) {
			$errors['city'] = __( 'City: enter a valid city.', 'avitime-woocommerce' );
		}
		if ( '' === $form['phone'] || ! WC_Validation::is_phone( $form['phone'] ) ) {
			$errors['phone'] = __( 'Phone: the carrier needs it for the delivery.', 'avitime-woocommerce' );
		}
		$countries = self::countries();
		if ( ! isset( $countries[ $form['country_iso'] ] ) ) {
			$errors['country_iso'] = __( 'The store does not ship to this country.', 'avitime-woocommerce' );
		} else {
			$locale   = WC()->countries->get_country_locale();
			$required = ! isset( $locale[ $form['country_iso'] ]['postcode']['required'] ) || $locale[ $form['country_iso'] ]['postcode']['required'];
			$hidden   = ! empty( $locale[ $form['country_iso'] ]['postcode']['hidden'] );
			if ( ! $hidden && ( ( $required && '' === $form['postcode'] ) || ( '' !== $form['postcode'] && ! WC_Validation::is_postcode( $form['postcode'], $form['country_iso'] ) ) ) ) {
				$errors['postcode'] = __( 'Postcode not valid for this country.', 'avitime-woocommerce' );
			}
		}
		return $errors;
	}

	/* ------------------------------------------------------------------ */
	/* 3. Order                                                            */
	/* ------------------------------------------------------------------ */

	/**
	 * @return WC_Order
	 * @throws Avitime_WC_Claim_Exception If the order cannot be created.
	 */
	public function place_order( $token, array $auth, array $form ) {
		global $wpdb;
		$table = Avitime_WC_Installer::claims_table();
		$hash  = self::hash_token( $token );
		$ref   = (string) $auth['authorization_ref'];
		$now   = current_time( 'mysql', true );

		// Local lock: one processing per link at a time.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$locked = $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$table} (token_hash, authorization_ref, status, order_id, created_at, updated_at) VALUES (%s, %s, 'processing', 0, %s, %s)", $hash, $ref, $now, $now ) );
		if ( 1 !== (int) $locked ) {
			// A previous attempt failed (« failed » row): take it over.
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
			$retaken = $wpdb->query( $wpdb->prepare( "UPDATE {$table} SET status = 'processing', updated_at = %s WHERE token_hash = %s AND status = 'failed'", $now, $hash ) );
			if ( 1 !== (int) $retaken ) {
				throw new Avitime_WC_Claim_Exception( __( 'Your order is already being registered. Wait a few seconds, then reload the page.', 'avitime-woocommerce' ) );
			}
		}

		$order    = null;
		$consumed = false;
		try {
			$order = $this->build_order( $auth, $form );

			// Atomic consumption at Avitime: if two calls arrive, only one succeeds.
			try {
				$this->api->consume_authorization( $token, $ref, $order->get_id() );
				$consumed = true;
			} catch ( Avitime_WC_Api_Exception $e ) {
				if ( 409 === $e->status ) {
					throw new Avitime_WC_Claim_Exception( __( 'This link has already been used.', 'avitime-woocommerce' ) );
				}
				Avitime_WC_Plugin::log( 'Link ' . $ref . ' could not be consumed: ' . $e->getMessage() );
				throw new Avitime_WC_Claim_Exception( __( 'Avitime cannot be reached right now. Your link remains valid: try again in a few minutes.', 'avitime-woocommerce' ) );
			}

			// Avitime learns about the order before any status change is reported.
			try {
				$this->api->report_order( Avitime_WC_Orders::order_payload( $order ) );
			} catch ( Avitime_WC_Api_Exception $e ) {
				$order->update_meta_data( Avitime_WC_Orders::META_PENDING, 1 );
				$order->save_meta_data();
				Avitime_WC_Plugin::log( 'Order ' . $order->get_id() . ' created but not reported to Avitime: ' . $e->getMessage() );
			}

			// Paid (€0): « Processing », stock reduced, usual store emails.
			$order->payment_complete( $ref );
			$order->add_order_note(
				sprintf(
					/* translators: 1: authorization reference, 2: mission reference. */
					__( 'Avitime tester order — authorization %1$s — mission %2$s. Product provided free for testing: do not cancel, do not refund. Ship as usual and enter the tracking number in the Avitime box.', 'avitime-woocommerce' ),
					$ref,
					isset( $auth['mission_ref'] ) ? $auth['mission_ref'] : '-'
				)
			);
		} catch ( Exception $e ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
			$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET status = 'failed', updated_at = %s WHERE token_hash = %s", current_time( 'mysql', true ), $hash ) );
			if ( $order && ! $consumed ) {
				$order->delete( true );
			}
			if ( $e instanceof Avitime_WC_Claim_Exception ) {
				throw $e;
			}
			Avitime_WC_Plugin::log( 'Order creation impossible for ' . $ref . ': ' . $e->getMessage() );
			throw new Avitime_WC_Claim_Exception( __( 'An error prevents the order from being created. Avitime has been notified; your link remains valid.', 'avitime-woocommerce' ) );
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET status = 'used', order_id = %d, updated_at = %s WHERE token_hash = %s", $order->get_id(), current_time( 'mysql', true ), $hash ) );

		return $order;
	}

	/**
	 * Pending order containing only the authorized product, at €0 with free shipping.
	 *
	 * @return WC_Order
	 * @throws Avitime_WC_Claim_Exception If the store refuses the order.
	 */
	protected function build_order( array $auth, array $form ) {
		/** @var WC_Product $item */
		$item     = $auth['_product'];
		$quantity = (int) $auth['product']['quantity'];
		$ref      = (string) $auth['authorization_ref'];
		$email    = sanitize_email( strtolower( trim( (string) $auth['tester']['email'] ) ) );
		if ( ! is_email( $email ) ) {
			throw new Avitime_WC_Claim_Exception( __( 'The email address sent by Avitime is not valid.', 'avitime-woocommerce' ) );
		}

		$order = wc_create_order(
			array(
				'status'      => 'pending',
				'customer_id' => 0,
				'created_via' => 'avitime',
			)
		);
		if ( is_wp_error( $order ) ) {
			throw new Avitime_WC_Claim_Exception( __( 'The order could not be created. Avitime has been notified.', 'avitime-woocommerce' ) );
		}

		$order->add_product(
			$item,
			$quantity,
			array(
				'subtotal' => 0,
				'total'    => 0,
			)
		);

		$address = array(
			'first_name' => $form['firstname'],
			'last_name'  => $form['lastname'],
			'address_1'  => $form['address1'],
			'address_2'  => $form['address2'],
			'postcode'   => $form['postcode'],
			'city'       => $form['city'],
			'country'    => $form['country_iso'],
			'phone'      => $form['phone'],
		);
		$order->set_address( array_merge( $address, array( 'email' => $email ) ), 'billing' );
		$order->set_address( $address, 'shipping' );

		$shipping = new WC_Order_Item_Shipping();
		$shipping->set_method_title( __( 'Free shipping – Avitime tester', 'avitime-woocommerce' ) );
		$shipping->set_method_id( 'avitime' );
		$shipping->set_total( 0 );
		$order->add_item( $shipping );

		$order->set_payment_method( self::PAYMENT_ID );
		$order->set_payment_method_title( self::payment_label() );
		$order->set_transaction_id( $ref );
		$order->update_meta_data( Avitime_WC_Orders::META_REF, $ref );
		$order->update_meta_data( Avitime_WC_Orders::META_MISSION, isset( $auth['mission_ref'] ) ? (string) $auth['mission_ref'] : '' );
		$order->update_meta_data( Avitime_WC_Orders::META_TESTER, isset( $auth['tester']['ref'] ) ? (string) $auth['tester']['ref'] : '' );
		$order->update_meta_data( Avitime_WC_Orders::META_EVENT, 'created' );
		$order->update_meta_data( Avitime_WC_Orders::META_PENDING, 0 );
		// « Origin » column of the orders list: Referral › Avitime.
		$order->update_meta_data( '_wc_order_attribution_source_type', 'referral' );
		$order->update_meta_data( '_wc_order_attribution_utm_source', 'avitime' );
		$order->calculate_totals( false );
		$order->save();

		// Final check: only the authorized product, at €0.
		$lines = $order->get_items();
		$line  = $lines ? reset( $lines ) : null;
		if ( 1 !== count( $lines ) || ! $line instanceof WC_Order_Item_Product
			|| (int) $line->get_quantity() !== $quantity
			|| (int) ( $line->get_variation_id() ? $line->get_variation_id() : $line->get_product_id() ) !== (int) $item->get_id() ) {
			$order->delete( true );
			throw new Avitime_WC_Claim_Exception( __( 'The order content does not match the link. Avitime has been notified.', 'avitime-woocommerce' ) );
		}
		if ( (float) $order->get_total() > 0.009 ) {
			$order->delete( true );
			Avitime_WC_Plugin::log( 'Non-zero total for ' . $ref . ': check fees added by other plugins.' );
			throw new Avitime_WC_Claim_Exception( __( 'The order total is not €0. Avitime has been notified; your link remains valid.', 'avitime-woocommerce' ) );
		}
		return $order;
	}
}
