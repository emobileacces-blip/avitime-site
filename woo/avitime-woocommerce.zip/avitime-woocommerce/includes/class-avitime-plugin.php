<?php
/**
 * Wires every hook of the plugin.
 *
 * @package Avitime
 */

defined( 'ABSPATH' ) || exit;

class Avitime_WC_Plugin {

	/** @var Avitime_WC_Plugin|null */
	protected static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	protected function __construct() {
		load_plugin_textdomain( 'avitime-woocommerce', false, dirname( plugin_basename( AVITIME_WC_FILE ) ) . '/languages' );

		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action( 'admin_notices', array( __CLASS__, 'missing_woocommerce' ) );
			return;
		}

		Avitime_WC_Installer::maybe_upgrade();

		// Public side.
		add_action( 'wp_loaded', array( 'Avitime_WC_Front', 'dispatch' ), 5 );
		add_action( 'wp_enqueue_scripts', array( 'Avitime_WC_Front', 'register_assets' ) );
		add_action( 'woocommerce_single_product_summary', array( 'Avitime_WC_Front', 'product_stars' ), 6 );
		add_action( 'woocommerce_after_single_product_summary', array( 'Avitime_WC_Front', 'product_reviews' ), 12 );
		add_filter( 'woocommerce_structured_data_product', array( 'Avitime_WC_Reviews', 'structured_data' ), 20, 2 );
		add_shortcode( 'avitime_reviews', array( 'Avitime_WC_Front', 'shortcode' ) );
		add_shortcode( 'avitime_stars', array( 'Avitime_WC_Front', 'shortcode_stars' ) );

		// Catalog.
		add_action( 'woocommerce_new_product', array( 'Avitime_WC_Catalog', 'queue' ) );
		add_action( 'woocommerce_update_product', array( 'Avitime_WC_Catalog', 'queue' ) );
		add_action( 'woocommerce_update_product_variation', array( 'Avitime_WC_Catalog', 'queue' ) );
		add_action( 'woocommerce_product_set_stock', array( __CLASS__, 'queue_product_object' ) );
		add_action( 'woocommerce_variation_set_stock', array( __CLASS__, 'queue_product_object' ) );
		add_action( 'trashed_post', array( 'Avitime_WC_Catalog', 'queue' ) );
		add_action( 'untrashed_post', array( 'Avitime_WC_Catalog', 'queue' ) );
		add_action( 'before_delete_post', array( 'Avitime_WC_Catalog', 'queue_delete' ) );

		// Orders.
		add_action( 'woocommerce_order_status_changed', array( 'Avitime_WC_Orders', 'on_status_changed' ), 10, 4 );
		add_action( 'woocommerce_process_shop_order_meta', array( 'Avitime_WC_Orders', 'save_tracking_box' ), 30 ); // Before WooCommerce saves the status (40): the « shipped » event carries the tracking.
		add_action( 'avitime_wc_retry', array( 'Avitime_WC_Orders', 'cron_retry' ) );

		// Back office.
		if ( is_admin() ) {
			add_action( 'admin_menu', array( 'Avitime_WC_Admin', 'menu' ), 60 );
			add_action( 'admin_init', array( 'Avitime_WC_Admin', 'handle' ) );
			add_action( 'admin_notices', array( 'Avitime_WC_Admin', 'notice' ) );
			add_action( 'add_meta_boxes', array( 'Avitime_WC_Admin', 'add_meta_box' ), 10, 2 );
			add_filter( 'plugin_action_links_' . plugin_basename( AVITIME_WC_FILE ), array( 'Avitime_WC_Admin', 'action_links' ) );
			// Orders list: HPOS and posts storage.
			add_filter( 'manage_woocommerce_page_wc-orders_columns', array( 'Avitime_WC_Admin', 'add_column' ) );
			add_action( 'manage_woocommerce_page_wc-orders_custom_column', array( 'Avitime_WC_Admin', 'render_column' ), 10, 2 );
			add_filter( 'manage_edit-shop_order_columns', array( 'Avitime_WC_Admin', 'add_column' ) );
			add_action( 'manage_shop_order_posts_custom_column', array( 'Avitime_WC_Admin', 'render_column' ), 10, 2 );
		}
	}

	public static function queue_product_object( $product ) {
		if ( $product instanceof WC_Product ) {
			Avitime_WC_Catalog::queue( $product->get_id() );
		}
	}

	public static function missing_woocommerce() {
		echo '<div class="notice notice-error"><p><b>Avitime</b> — ' . esc_html__( 'This plugin needs WooCommerce. Install and activate WooCommerce first.', 'avitime-woocommerce' ) . '</p></div>';
	}

	/** Writes to WooCommerce › Status › Logs (source « avitime »). */
	public static function log( $message, $level = 'warning' ) {
		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->log( $level, (string) $message, array( 'source' => 'avitime' ) );
		}
	}
}
