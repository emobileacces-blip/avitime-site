<?php
/**
 * Plugin Name:          Avitime – Tester reviews for WooCommerce
 * Plugin URI:           https://avitime.fr
 * Description:          Receive your Avitime testers' €0 orders, report their shipping to Avitime and show their verified, clearly labeled reviews on your product pages.
 * Version:              1.0.0
 * Author:               Avitime (SPARKMOTION AGENCY LTD)
 * Author URI:           https://avitime.fr
 * Text Domain:          avitime-woocommerce
 * Domain Path:          /languages
 * Requires at least:    6.2
 * Requires PHP:         7.4
 * Requires Plugins:     woocommerce
 * WC requires at least: 7.0
 * WC tested up to:      10.2
 * License:              Proprietary — all rights reserved
 *
 * @package Avitime
 */

defined( 'ABSPATH' ) || exit;

define( 'AVITIME_WC_VERSION', '1.0.0' );
define( 'AVITIME_WC_FILE', __FILE__ );
define( 'AVITIME_WC_DIR', plugin_dir_path( __FILE__ ) );
define( 'AVITIME_WC_URL', plugin_dir_url( __FILE__ ) );

require_once AVITIME_WC_DIR . 'includes/class-avitime-api.php';
require_once AVITIME_WC_DIR . 'includes/class-avitime-installer.php';
require_once AVITIME_WC_DIR . 'includes/class-avitime-catalog.php';
require_once AVITIME_WC_DIR . 'includes/class-avitime-orders.php';
require_once AVITIME_WC_DIR . 'includes/class-avitime-claim.php';
require_once AVITIME_WC_DIR . 'includes/class-avitime-reviews.php';
require_once AVITIME_WC_DIR . 'includes/class-avitime-front.php';
require_once AVITIME_WC_DIR . 'includes/class-avitime-admin.php';
require_once AVITIME_WC_DIR . 'includes/class-avitime-plugin.php';

// Compatible with High-Performance Order Storage and the block checkout.
add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', AVITIME_WC_FILE, true );
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', AVITIME_WC_FILE, true );
		}
	}
);

register_activation_hook( __FILE__, array( 'Avitime_WC_Installer', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Avitime_WC_Installer', 'deactivate' ) );

add_action( 'plugins_loaded', array( 'Avitime_WC_Plugin', 'instance' ), 20 );
