=== Avitime – Tester reviews for WooCommerce ===
Contributors: avitime
Tags: reviews, product reviews, product testing, verified reviews, woocommerce
Requires at least: 6.2
Tested up to: 6.8
Requires PHP: 7.4
WC requires at least: 7.0
Stable tag: 1.0.0
License: Proprietary

Send products to selected testers and show their honest, clearly labeled reviews on your product pages.

== Description ==

Avitime connects your WooCommerce store with testers selected and verified by Avitime.

* Pick a product and the number of testers in your Avitime space.
* Each selected tester orders through a single-use link: a €0 order with free shipping is created in your store, ready to ship.
* Ship as usual, enter the tracking number in the Avitime box of the order and mark it « Completed »: Avitime follows the delivery.
* The tester publishes a detailed review (rating, pros, cons, photos). After moderation it appears on your product page with the label « Product provided free for testing ».
* The rating is added to the product data read by Google and AI assistants (schema.org).

== Installation ==

1. Plugins → Add New Plugin → Upload Plugin, choose avitime-woocommerce.zip, then Activate.
2. WooCommerce → Avitime → « Connect to Avitime », log in to your Avitime merchant space and authorize.
3. Your catalog is sent automatically. Create your first campaign in your Avitime space.

Theme or page builder without the usual WooCommerce areas? Use the shortcodes [avitime_reviews] and [avitime_stars].

== Changelog ==

= 1.0.0 =
* First version: connection, catalog sync, €0 tester orders, shipping and tracking events, reviews block, stars, structured data, HPOS compatible.
