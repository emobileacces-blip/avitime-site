<?php
/**
 * Avitime tester order page (standalone page, independent of the theme).
 *
 * Variable: $avt (see Avitime_WC_Front::claim()).
 *
 * @package Avitime
 */

defined( 'ABSPATH' ) || exit;

$avt_title = __( 'Your Avitime tester order', 'avitime-woocommerce' );
$avt_logo  = get_theme_mod( 'custom_logo' ) ? wp_get_attachment_image_url( (int) get_theme_mod( 'custom_logo' ), 'medium' ) : '';
$avt_field = function ( $name, $label, $attrs = '' ) use ( $avt ) {
	$value   = isset( $avt['form'][ $name ] ) ? $avt['form'][ $name ] : '';
	$invalid = isset( $avt['form_errors'][ $name ] ) ? ' aria-invalid="true"' : '';
	$wide    = in_array( $name, array( 'address1', 'address2' ), true ) ? ' avt-field--wide' : '';
	echo '<label class="avt-field' . esc_attr( $wide ) . '">' . esc_html( $label )
		. '<input name="avt_' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" ' . $attrs . $invalid . '></label>'; // phpcs:ignore WordPress.Security.EscapeOutput -- $attrs are fixed strings below.
};
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?php echo esc_html( $avt_title . ' — ' . get_bloginfo( 'name' ) ); ?></title>
<link rel="stylesheet" href="<?php echo esc_url( AVITIME_WC_URL . 'assets/front.css?ver=' . AVITIME_WC_VERSION ); ?>">
<style>
body{margin:0;background:#f6f4f1;color:#1a1a1a;font:16px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
.avt-top{background:#fff;border-bottom:1px solid #e6e3de;padding:14px 16px;text-align:center}
.avt-top a{color:#1a1a1a;text-decoration:none;font-weight:700;font-size:1.1rem}
.avt-top img{max-height:48px;width:auto;vertical-align:middle}
.avt-wrap{padding:28px 16px 48px}
.avt-wrap h1{max-width:760px;margin:0 auto 18px;font-size:1.6rem}
.avt-submit{background:#1a1a1a;color:#fff;border:0;border-radius:12px;font-weight:700;cursor:pointer}
.avt-submit:hover{background:#000}
</style>
</head>
<body>
<header class="avt-top"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo $avt_logo ? '<img src="' . esc_url( $avt_logo ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '">' : esc_html( get_bloginfo( 'name' ) ); ?></a></header>
<main class="avt-wrap">
<h1><?php echo esc_html( $avt_title ); ?></h1>
<div class="avt-claim">

<?php if ( $avt['error'] ) : ?>
	<section class="avt-card avt-card--error" role="alert">
		<h2><?php esc_html_e( 'This link cannot be used', 'avitime-woocommerce' ); ?></h2>
		<p><?php echo esc_html( $avt['error'] ); ?></p>
		<p class="avt-muted"><?php esc_html_e( 'If you think this is a mistake, contact Avitime from your tester space.', 'avitime-woocommerce' ); ?></p>
	</section>

<?php elseif ( $avt['done'] ) : ?>
	<section class="avt-card avt-card--ok" role="status">
		<span class="avt-check" aria-hidden="true">✓</span>
		<h2><?php esc_html_e( 'Order registered', 'avitime-woocommerce' ); ?></h2>
		<p><?php echo esc_html( sprintf( /* translators: %s: tester first name. */ __( 'Thank you %s! The store will ship your product.', 'avitime-woocommerce' ), $avt['done']['firstname'] ) ); ?></p>
		<dl class="avt-kv">
			<div><dt><?php esc_html_e( 'Order number', 'avitime-woocommerce' ); ?></dt><dd><?php echo esc_html( $avt['done']['reference'] ); ?></dd></div>
			<div><dt><?php esc_html_e( 'Product', 'avitime-woocommerce' ); ?></dt><dd><?php echo esc_html( $avt['item']['name'] ); ?> × <?php echo (int) $avt['item']['quantity']; ?></dd></div>
			<div><dt><?php esc_html_e( 'Total', 'avitime-woocommerce' ); ?></dt><dd><?php echo wp_kses_post( wc_price( 0 ) ); ?></dd></div>
		</dl>
		<p><?php esc_html_e( 'Your test starts on delivery. You will then have 21 days to publish your review from your Avitime tester space, with a reminder every 7 days.', 'avitime-woocommerce' ); ?></p>
	</section>

<?php else : ?>
	<section class="avt-card avt-product">
		<?php if ( $avt['item']['image'] ) : ?>
			<img src="<?php echo esc_url( $avt['item']['image'] ); ?>" alt="" width="160" height="160" loading="lazy">
		<?php endif; ?>
		<div class="avt-product__info">
			<span class="avt-badge">★ <?php esc_html_e( 'Product provided free for testing', 'avitime-woocommerce' ); ?></span>
			<h2><?php echo esc_html( $avt['item']['name'] ); ?></h2>
			<p class="avt-muted"><?php esc_html_e( 'Quantity', 'avitime-woocommerce' ); ?> : <?php echo (int) $avt['item']['quantity']; ?> · <?php esc_html_e( 'Mission', 'avitime-woocommerce' ); ?> <?php echo esc_html( $avt['item']['mission_ref'] ); ?></p>
			<p class="avt-price"><?php echo wp_kses_post( wc_price( 0 ) ); ?> <span class="avt-muted"><?php esc_html_e( 'shipping included', 'avitime-woocommerce' ); ?></span></p>
		</div>
	</section>

	<form class="avt-card avt-form" method="post" action="<?php echo esc_url( $avt['action'] ); ?>" novalidate>
		<h2><?php esc_html_e( 'Shipping address', 'avitime-woocommerce' ); ?></h2>
		<p class="avt-muted"><?php esc_html_e( 'Check your address: it is only used by the store to deliver this parcel.', 'avitime-woocommerce' ); ?></p>

		<?php if ( $avt['form_errors'] ) : ?>
			<ul class="avt-errors" role="alert">
				<?php foreach ( $avt['form_errors'] as $err ) : ?><li><?php echo esc_html( $err ); ?></li><?php endforeach; ?>
			</ul>
		<?php endif; ?>

		<div class="avt-grid">
			<?php
			$avt_field( 'firstname', __( 'First name', 'avitime-woocommerce' ), 'autocomplete="given-name" required' );
			$avt_field( 'lastname', __( 'Last name', 'avitime-woocommerce' ), 'autocomplete="family-name" required' );
			$avt_field( 'address1', __( 'Address', 'avitime-woocommerce' ), 'autocomplete="address-line1" required' );
			$avt_field( 'address2', __( 'Address line 2 (optional)', 'avitime-woocommerce' ), 'autocomplete="address-line2"' );
			$avt_field( 'postcode', __( 'Postcode', 'avitime-woocommerce' ), 'autocomplete="postal-code"' );
			$avt_field( 'city', __( 'City', 'avitime-woocommerce' ), 'autocomplete="address-level2" required' );
			?>
			<label class="avt-field"><?php esc_html_e( 'Country', 'avitime-woocommerce' ); ?>
				<select name="avt_country_iso" autocomplete="country">
					<?php foreach ( $avt['countries'] as $iso => $name ) : ?>
						<option value="<?php echo esc_attr( $iso ); ?>"<?php selected( $iso, $avt['form']['country_iso'] ); ?>><?php echo esc_html( html_entity_decode( $name ) ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
			<?php $avt_field( 'phone', __( 'Phone', 'avitime-woocommerce' ), 'autocomplete="tel" inputmode="tel" required' ); ?>
		</div>

		<input type="hidden" name="t" value="<?php echo esc_attr( $avt['token'] ); ?>">
		<input type="hidden" name="avt_csrf" value="<?php echo esc_attr( $avt['csrf'] ); ?>">
		<button type="submit" name="avitime_confirm" value="1" class="avt-submit"><?php echo esc_html( sprintf( /* translators: %s: €0 price. */ __( 'Confirm my order at %s', 'avitime-woocommerce' ), wp_strip_all_tags( wc_price( 0 ) ) ) ); ?></button>
		<p class="avt-muted avt-small"><?php esc_html_e( 'No payment is requested. This link only works once, for this product only.', 'avitime-woocommerce' ); ?></p>
	</form>
<?php endif; ?>

</div>
</main>
</body>
</html>
