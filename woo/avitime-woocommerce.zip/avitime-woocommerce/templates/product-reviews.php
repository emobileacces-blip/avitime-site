<?php
/**
 * Avitime reviews block on the product page.
 *
 * Variables: $data (normalized reviews), $pct (average in %).
 *
 * @package Avitime
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="avt-reviews" id="avitime-reviews" aria-labelledby="avt-reviews-title">
	<header class="avt-reviews__head">
		<h2 id="avt-reviews-title"><?php esc_html_e( 'Avitime tester reviews', 'avitime-woocommerce' ); ?></h2>
		<div class="avt-reviews__score">
			<span class="avt-stars" style="--avt-pct:<?php echo (int) $pct; ?>%" aria-hidden="true"></span>
			<b><?php echo esc_html( number_format_i18n( (float) $data['average'], 1 ) ); ?>/5</b>
			<span class="avt-muted">· <?php echo esc_html( sprintf( /* translators: %d: number of reviews. */ _n( '%d review', '%d reviews', (int) $data['count'], 'avitime-woocommerce' ), (int) $data['count'] ) ); ?></span>
		</div>
		<p class="avt-notice">✓ <?php echo esc_html( Avitime_WC_Reviews::notice() ); ?></p>
	</header>

	<ol class="avt-reviews__list">
		<?php foreach ( $data['reviews'] as $r ) : ?>
			<li class="avt-review">
				<div class="avt-review__top">
					<span class="avt-stars" style="--avt-pct:<?php echo (int) ( $r['rating'] * 20 ); ?>%" role="img" aria-label="<?php echo esc_attr( sprintf( /* translators: %d: rating. */ __( '%d out of 5', 'avitime-woocommerce' ), (int) $r['rating'] ) ); ?>"></span>
					<?php if ( $r['title'] ) : ?><b><?php echo esc_html( $r['title'] ); ?></b><?php endif; ?>
				</div>
				<p><?php echo nl2br( esc_html( $r['body'] ) ); ?></p>
				<?php if ( $r['pros'] || $r['cons'] ) : ?>
					<dl class="avt-review__proscons">
						<?php if ( $r['pros'] ) : ?><div class="avt-pros"><dt><?php esc_html_e( 'Pros', 'avitime-woocommerce' ); ?></dt><dd><?php echo nl2br( esc_html( $r['pros'] ) ); ?></dd></div><?php endif; ?>
						<?php if ( $r['cons'] ) : ?><div class="avt-cons"><dt><?php esc_html_e( 'Cons', 'avitime-woocommerce' ); ?></dt><dd><?php echo nl2br( esc_html( $r['cons'] ) ); ?></dd></div><?php endif; ?>
					</dl>
				<?php endif; ?>
				<?php if ( null !== $r['recommend'] || $r['audience'] ) : ?>
					<p class="avt-review__reco">
						<?php if ( true === $r['recommend'] ) : ?>
							<b class="avt-yes"><?php esc_html_e( 'Recommends this product', 'avitime-woocommerce' ); ?></b>
						<?php elseif ( false === $r['recommend'] ) : ?>
							<b class="avt-no"><?php esc_html_e( 'Does not recommend this product', 'avitime-woocommerce' ); ?></b>
						<?php endif; ?>
						<?php if ( $r['audience'] ) : ?>
							<?php echo null !== $r['recommend'] ? ' · ' : ''; ?><?php esc_html_e( 'Ideal for:', 'avitime-woocommerce' ); ?> <?php echo esc_html( $r['audience'] ); ?>
						<?php endif; ?>
					</p>
				<?php endif; ?>
				<?php if ( $r['media'] ) : ?>
					<div class="avt-review__media">
						<?php foreach ( $r['media'] as $m ) : ?>
							<a href="<?php echo esc_url( $m['url'] ); ?>" target="_blank" rel="noopener"><img src="<?php echo esc_url( $m['thumb'] ); ?>" alt="<?php esc_attr_e( 'Tester photo', 'avitime-woocommerce' ); ?>" loading="lazy" width="96" height="96"></a>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
				<p class="avt-review__meta">
					<?php
					$meta = array();
					if ( $r['display_name'] ) {
						$meta[] = $r['display_name'];
					}
					if ( $r['grade'] ) {
						/* translators: %s: tester grade (Bronze, Argent, Gold, Black). */
						$meta[] = sprintf( __( '%s tester', 'avitime-woocommerce' ), $r['grade'] );
					}
					if ( $r['usage_duration'] ) {
						/* translators: %s: usage duration, e.g. « 2 weeks ». */
						$meta[] = sprintf( __( 'used %s', 'avitime-woocommerce' ), $r['usage_duration'] );
					}
					if ( $r['published_at'] ) {
						$meta[] = date_i18n( get_option( 'date_format' ), strtotime( $r['published_at'] ) );
					}
					echo esc_html( implode( ' · ', $meta ) );
					?>
				</p>
				<?php if ( $r['reply'] ) : ?>
					<div class="avt-review__reply"><b><?php esc_html_e( 'Reply from the store', 'avitime-woocommerce' ); ?></b><p><?php echo nl2br( esc_html( $r['reply'] ) ); ?></p></div>
				<?php endif; ?>
			</li>
		<?php endforeach; ?>
	</ol>
</section>
