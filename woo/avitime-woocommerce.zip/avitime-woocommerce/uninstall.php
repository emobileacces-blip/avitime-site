<?php
/**
 * Uninstall: removes the Avitime settings and the links table. Tester orders stay in the store.
 *
 * @package Avitime
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;

foreach ( array( 'avitime_shop_key', 'avitime_shop_secret', 'avitime_shop_id', 'avitime_shop_name', 'avitime_connect_state', 'avitime_api_url', 'avitime_app_url', 'avitime_reviews_block', 'avitime_stars', 'avitime_schema', 'avitime_last_sync', 'avitime_db_version' ) as $avitime_option ) {
	delete_option( $avitime_option );
}
wp_clear_scheduled_hook( 'avitime_wc_retry' );
// phpcs:disable WordPress.DB.DirectDatabaseQuery
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_avitime\\_%' OR option_name LIKE '\\_transient\\_timeout\\_avitime\\_%'" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}avitime_claims" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
// phpcs:enable
